#pragma once
#include "src/LowPassFilter/Lpf.h"
#define BANDWIDTH_HZ    1     // 3-dB bandwidth of the filter

LPF lpf_E(BANDWIDTH_HZ, IS_BANDWIDTH_HZ, 3);
LPF lpf_U(BANDWIDTH_HZ, IS_BANDWIDTH_HZ, 3);
LPF lpf_I(BANDWIDTH_HZ, IS_BANDWIDTH_HZ, 3);


// Get next value from the filter based on the input (current) value
// double NextValue ( double currentValue );

/*
void setup() {
  Serial.begin(115200);
  Serial.printf("size of double: %d\n", sizeof(double));
  Serial.printf("size of float: %d\n", sizeof(float));
}
void loop() {}
*/
