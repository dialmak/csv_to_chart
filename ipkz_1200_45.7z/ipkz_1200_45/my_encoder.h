#pragma once
#include "src/EncoderStepCounter/EncoderStepCounter.h"

// імя та номер піну енкодеру
#define ENCODER_PIN1   25   // кнопка енкодера LEFT
#define ENCODER_PIN2   33   // кнопка енкодера RIGHT

EncoderStepCounter encoder(ENCODER_PIN1, ENCODER_PIN2, FULL_STEP);

//---------------------------------

void IRAM_ATTR encoderInterrupt();
void initEncoder();
void encoderRead(bool logging = false, bool calc = false);

//---------------------------------

void IRAM_ATTR encoderInterrupt() {
  encoder.tick();
}

void initEncoder() {
  // Ініціалізація енкодера
  encoder.begin();
  // Ініціалізація переривань
  attachInterrupt(digitalPinToInterrupt(ENCODER_PIN1), encoderInterrupt, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_PIN2), encoderInterrupt, CHANGE);
}


void encoderRead(bool logging, bool calc) {
  uint32_t startMicros  =  micros();

  signed char pos = encoder.getPosition();
  int8_t changeValue = 10;
  int16_t tmp_set;
  // прочитати налаштування preset.setU, preset.setI, preset.mod
  // getPreset();

  if (pos != 0) {
    buzzerBeep(10);
    if (digitalRead(btnENCODER_PIN) == LOW) {// если false кнопка нажата, true - не нажата
      changeValue = 100;
    }
    encoder.reset();

    // перезапускаємо таймер timerSetup, якщо він був запущений
    if (timerSetup.active()) {
      timerSetup.detach();
      timerSetup.once_ms(TIMER_SETUP, endSetup, true);
    }

    if (timerSetupPotencial.active()) {
      timerSetupPotencial.detach();
      timerSetupPotencial.once_ms(TIMER_SETUP, timerPotencialOff);
    }

    if (pos < 0) {

      // Прочитати вихідну напругу, струм та температуру
      readCotekOutputUIT();

      if (logging)(log_i ("Encoder LEFT, %hd", changeValue));


      if (preset.mod == SET_STAB_U) {
        tmp_set = preset.setU - changeValue;
        if (tmp_set <= (int16_t)MIN_U) tmp_set = (int16_t)MIN_U;
        preset.setU = tmp_set;
        setting.putShort("setU", preset.setU);
        cotekSetUI ();

      } else if (preset.mod == SET_STAB_I) {
        tmp_set = preset.setI - changeValue;
        if (tmp_set <= (int16_t)MIN_I) tmp_set = (int16_t)MIN_I;
        preset.setI = tmp_set;
        setting.putShort("setI", preset.setI);
        preset.setUI = setting.getShort("setUI");
        cotekSetUI ();

      } else if (preset.mod == SET_STAB_E) {
        tmp_set = preset.setE + 10;
        if (tmp_set <= (int16_t)MIN_E) tmp_set = (int16_t)MIN_E;
        if (tmp_set >= (int16_t)MAX_E) tmp_set = (int16_t)MAX_E;
        preset.setE = tmp_set;
        setting.putShort("setE", preset.setE);
        preset.setIE = setting.getShort("setIE");
        preset.setUI = setting.getShort("setUI");
        cotekSetUI ();
      } else {
        if ((preset.pageid >= 3) and (preset.pageid <= 10)) sendNextionCommand(bLeft);
      }
    } else if (pos > 0) {
      if (logging)(log_i ("Encoder RIGHT, %hd", changeValue));

      if (preset.mod == SET_STAB_U) {
        if (preset.raw_outI >= (uint16_t)MAX_I) return;
        if (preset.raw_outI >= (uint16_t)(MAX_I - MAX_I / 5) and (changeValue ==  100)) changeValue = 10;
        if (preset.setU > (uint16_t)(MAX_U - MAX_U / 5) and (changeValue ==  100)) changeValue = 10;
        tmp_set =  preset.setU + changeValue;
        if (tmp_set >= (int16_t)MAX_U) tmp_set = (int16_t)MAX_U;
        preset.setU = tmp_set;
        setting.putShort("setU", preset.setU);
        cotekSetUI ();

      } else if (preset.mod == SET_STAB_I) {
        if (preset.raw_outU >= (uint16_t)MAX_U) return;
        if (preset.raw_outU >= (uint16_t)(MAX_U - MAX_U / 5) and (changeValue == 100)) changeValue = 10;
        if (preset.setI > (uint16_t)(MAX_I - MAX_I / 5) and (changeValue ==  100)) changeValue = 10;
        tmp_set =  preset.setI + changeValue;
        if (tmp_set >= (int16_t)MAX_I) tmp_set = (int16_t)MAX_I;
        preset.setI = tmp_set;
        setting.putShort("setI", preset.setI);
        preset.setUI = setting.getShort("setUI");
        cotekSetUI ();

      } else if (preset.mod == SET_STAB_E) {
        if (preset.raw_outU >= (uint16_t)MAX_U) return;
        if (preset.raw_outI >= (uint16_t)MAX_I) return;
        tmp_set = preset.setE  -  10;
        if (tmp_set >= (int16_t)MAX_E) tmp_set = (int16_t)MAX_E;
        if (tmp_set <= (int16_t)MIN_E) tmp_set = (int16_t)MIN_E;
        preset.setE = tmp_set;
        setting.putShort("setE", preset.setE);
        preset.setIE = setting.getShort("setIE");
        preset.setUI = setting.getShort("setUI");
        cotekSetUI ();
      } else {
        if ((preset.pageid >= 3) and (preset.pageid <= 10)) sendNextionCommand(bRight);
      }
    }

    if (logging) {
      log_i("preset.outU: %hd", preset.outU);
      log_i("preset.setU: %hd", preset.setU);
      log_i("---");
      log_i("preset.outI: %hd", preset.outI);
      log_i("preset.setI: %hd", preset.setI);
      log_i("---");
      log_i("preset.outE: %hd", preset.outE);
      log_i("preset.setE: %hd", preset.setE);
      log_i("preset.setIE: %hd", preset.setIE);
      log_i(" ");
    }
    if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer encoderRead: %.1f", (micros() - startMicros) / 1000.0f);
  }

}


/*
  void setup() {

  // Ініціалізація енкодера
  encoder.begin();
  // Ініціалізація переривань
  attachInterrupt(digitalPinToInterrupt(ENCODER_PIN1), encoderInterrupt, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_PIN2), encoderInterrupt, CHANGE);

  }

  void loop() {
  encoderRead();
  }
*/
