#pragma once

// імя та номер піну для переривача струму
#define SWITCH_CURRENT_PIN 13 // вхід для переривача струму

Ticker tickerPowerOn;
Ticker tickerPowerOff;

void powerOff();
void powerOn();

void powerOff() {
  tickerPowerOn.once_ms(1000, powerOn);
}

void powerOn() {
  tickerPowerOff.once_ms(5000, powerOff);
}
