/***************************************************************************
  Example sketch for the INA219_WE library

  This sketch shows how to use the INA219 module in continuous mode.

  Further information can be found on:
  https://wolles-elektronikkiste.de/ina219 (German)
  https://wolles-elektronikkiste.de/en/ina219-current-and-power-sensor (English)

***************************************************************************/
#include <Wire.h>
#include "src/INA219_WE/INA219_WE.h"
#define I2C_INA219 0x40
#define CORRECTION_INA219 1.050f    // коефіцієнт корекції
#define OFFSET_VOLTAGE    4.99f     // зміщення напруги відносно нуля
#define ZERO_OFFSET       5.00f     // зміщення напруги відносно нуля при відкритому вході
/* There are several ways to create your INA219 object:
   INA219_WE ina219 = INA219_WE()              -> uses Wire / I2C Address = 0x40
   INA219_WE ina219 = INA219_WE(ICM20948_ADDR) -> uses Wire / I2C_ADDRESS
   INA219_WE ina219 = INA219_WE(&wire2)        -> uses the TwoWire object wire2 / I2C_ADDRESS
   INA219_WE ina219 = INA219_WE(&wire2, I2C_ADDRESS) -> all together
   Successfully tested with two I2C busses on an ESP32
*/
INA219_WE ina219 = INA219_WE(I2C_INA219);

void ina219Init();
void potencialRead(unsigned long timeout_us = 50000UL, bool calc = false);
void timerPotencialRead(unsigned long timeout_ms = 100UL, unsigned long timeout_us = 50000UL);

//---------------------------------


void ina219Init() {
  /* Set ADC Mode for Bus and ShuntVoltage
    Mode *            * Res / Samples *       * Conversion Time
    BIT_MODE_9        9 Bit Resolution             84 µs
    BIT_MODE_10       10 Bit Resolution            148 µs
    BIT_MODE_11       11 Bit Resolution            276 µs
    BIT_MODE_12       12 Bit Resolution            532 µs  (DEFAULT)
    SAMPLE_MODE_2     Mean Value 2 samples         1.06 ms
    SAMPLE_MODE_4     Mean Value 4 samples         2.13 ms
    SAMPLE_MODE_8     Mean Value 8 samples         4.26 ms
    SAMPLE_MODE_16    Mean Value 16 samples        8.51 ms
    SAMPLE_MODE_32    Mean Value 32 samples        17.02 ms
    SAMPLE_MODE_64    Mean Value 64 samples        34.05 ms
    SAMPLE_MODE_128   Mean Value 128 samples       68.10 ms
  */
  ina219.setADCMode(SAMPLE_MODE_32); // choose mode and uncomment for change of default

  /* Set measure mode
    POWER_DOWN - INA219 switched off
    TRIGGERED  - measurement on demand
    ADC_OFF    - Analog/Digital Converter switched off
    CONTINUOUS  - Continuous measurements
    BUS_CONTINUOUS - Continuous bus measurements (DEFAULT)
  */
  ina219.setMeasureMode(BUS_CONTINUOUS); // choose mode and uncomment for change of default

  /* Set PGain
    Gain *  * Shunt Voltage Range *   * Max Current (if shunt is 0.1 ohms)
    PG_40       40 mV                    0.4 A
    PG_80       80 mV                    0.8 A
    PG_160      160 mV                   1.6 A
    PG_320      320 mV                   3.2 A (DEFAULT)
  */
  ina219.setPGain(PG_40); // choose gain and uncomment for change of default

  /* Set Bus Voltage Range
    BRNG_16   -> 16 V
    BRNG_32   -> 32 V (DEFAULT)
  */
  ina219.setBusRange(BRNG_32); // choose range and uncomment for change of default

  /* If the current values delivered by the INA219 differ by a constant factor
     from values obtained with calibrated equipment you can define a correction factor.
     Correction factor = current delivered from calibrated equipment / current delivered by INA219
  */
  // ina219.setCorrectionFactor(0.98); // insert your correction factor if necessary

  /* If you experience a shunt voltage offset, that means you detect a shunt voltage which is not
     zero, although the current should be zero, you can apply a correction. For this, uncomment the
     following function and apply the offset you have detected.
  */
  ina219.setShuntVoltOffset_mV(0.0); // insert the shunt voltage (millivolts) you detect at zero current

}

void potencialRead(unsigned long timeout_us, bool calc) {
  uint32_t startMicros  =  micros();
  preset.outE = 0;

  if (errors_flags.read(NO_WORK_INA219)) return; // якщо INA219 не працює

  float busVoltage = 0.0;
  busVoltage = ina219.getBusVoltage(timeout_us);
  if (busVoltage < 100.0f) {
    float bus = (busVoltage - OFFSET_VOLTAGE) * 100.0f * CORRECTION_INA219;
    float tmp = filterE.filtered(bus);
    if (tmp > ZERO_OFFSET) {
      clear_setting(NO_ELECTROD, "Електрод порівняння підключений.");
      preset.outE = -(tmp + 0.5);
    } else if (tmp < -ZERO_OFFSET) {
      clear_setting(NO_ELECTROD, "Електрод порівняння підключений.");
      preset.outE = -(tmp - 0.5);
    } else {
      set_setting (NO_ELECTROD, "Увага! Електрод порівняння не підключений!");
      preset.outE = 0;
    }
    if ((preset.outE > 500) or (preset.outE <= -1000)) {
      set_error (OUT_RANGE_POTENCIAL, "Захисний потенціал не в діапазоні. Захисний потенціал має бути в діапазоні від мінус 10.0 до плюс 5.0 вольт. Вимірювання захисного потенціалу неможливе.");
    } else {
      clear_error (OUT_RANGE_POTENCIAL, " ");
    }
    clear_error (ERROR_POTENCIAL, " ");
    log_d("busVoltage               : %.2f V", busVoltage);
    log_d("Raw bus                  : %.2f V", bus);
    log_d("filterE.filtered(bus)    : %.2f V", tmp);
    log_d("preset.outE hd           : %hd V", preset.outE);
  } else {
    set_error (ERROR_POTENCIAL, "Помилка вимірювання захисного потенціалу.");
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer potencialRead: %.1f", (micros() - startMicros) / 1000.0f);
}

void timerPotencialRead(unsigned long timeout_ms, unsigned long timeout_us) {
  static volatile uint32_t timerStart = millis();
  if (millis() - timerStart > timeout_ms) {
    // скидання таймера
    timerStart = millis();
    // прочитати потенціал preset.outE
    potencialRead(timeout_us);
  }
}
