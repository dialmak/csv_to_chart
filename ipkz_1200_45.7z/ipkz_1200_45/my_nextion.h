#pragma once

#include "src/nextion/Nextion.h" // INCLUDE https://dan-nixon.com/NeoNextion/index.html
#include "src/esp32time/esp32time.h"

ESP32Time rtc;

Nextion nex(Serial2);

//---------------------------------------
static char bLeft[] = "click bLeft,0";
static char bRight[] = "click bRight,0";
static char bOK[] = "click bOK,0";
static char bHold[] = "click mBack,0";

void SerialClean();
void Serial2Clean();
bool sendNextionCommand(const char *command);
void nextionInit();
void transferDataNextion(bool calc = false);
bool nextionGetVariable(const char *var, int32_t &value);
bool nextionSetVariable(const char *var, int32_t value);
bool transferNewPIDSettings(bool calc = false);
bool transferPIDSettings(bool calc = false);
bool transferDefaultPIDSettings(bool calc = false);
bool transferNewMeterSettings(bool calc = false);
bool transferMeterSettings(bool calc = false);
bool transferNewDateTime (bool calc = false);
bool transferDateTime();
void readNextionPIDSettings();

//---------------------------------------
// Очистити буфер Serial
void SerialClean() {
  while (Serial.available())
    Serial.read();
}

// Очистити буфер Serial2
void Serial2Clean() {
  while (Serial2.available())
    Serial2.read();
}


// Прочитати дату та час з NEXTION та встановити в ESP32
bool transferDateTime() {
  log_d("Set DateTime in ESP32");
  bool ret[6] = {0};

  int32_t Year, Month, Day, Hour, Minute, Second;
  ret[0] = nex.getVariable("rtc0", Year); // rtc0 Year
  ret[1] = nex.getVariable("rtc1", Month); // rtc1 Month
  ret[2] = nex.getVariable("rtc2", Day); // rtc2 Day
  ret[3] = nex.getVariable("rtc3", Hour); // rtc3 Hour
  ret[4] = nex.getVariable("rtc4", Minute); // rtc4 Minute
  ret[5] = nex.getVariable("rtc5", Second); // rtc5 Second

  if (Year == (uint32_t)2021) {
    set_error (INCORRECT_DATE, "Невірна дата, встановіть коректну дату та час.");
  } else {
    clear_error (INCORRECT_DATE, "Дата та час встановлений вірно.");
  }

  //rtc.setTime(30, 24, 15, 17, 1, 2021);  // 17.01.2021 15:24:30
  log_i("Year=%lu Month=%lu Day=%lu Hour=%lu Minute=%lu Second=%lu", Year, Month, Day, Hour, Minute, Second);
  rtc.setTime((uint16_t)Second, (uint16_t)Minute, (uint16_t)Hour, (uint16_t)Day, (uint16_t)Month, (uint16_t)Year);
  if (ret[0] && ret[1] && ret[2] && ret[3] && ret[4] && ret[5]) {
    clear_error(ERROR_DATE_TIME, "");
  } else {
    set_error(ERROR_DATE_TIME, "Помилка встановлення дати!");
  }
  return (ret[0] && ret[1] && ret[2] && ret[3] && ret[4] && ret[5]);
}

void nextionInit() {
  // Ініціалізація Nextion  
  Serial2Clean();
  Serial2.flush();

  if (nex.init()) {
    clear_error(NO_WORK_NEXTION, "Дісплей працює!");
  } else {
    set_error(NO_WORK_NEXTION, "Дісплей не працює або немаю живлення дісплея або немає зв'язку з дісплеєм.");
  } 
  Serial2Clean();
  Serial2.flush();

}
/*
  int16_t  setU;      // уставка напруги, вольт * 10
  int16_t  setI;      // уставка струму,  ампер * 10
  int16_t  setIE;     // уставка струму для потеціалу, вольт * 100
  int16_t  setE;      // уставка потеціалу, вольт * 100

  int16_t  outU ;     // вихідна напруга, вольт * 10
  int16_t  outI ;     // вихідний струм,  ампер * 10
  int16_t  outE ;     // вихідний потеціал, вольт * 100
  int16_t  outT ;     // температура, град. цельсія * 10
  int16_t  airT ;     // температура повітря, град. цельсія * 10

  int16_t  nofiltered_outU ;     // вихідна напруга без цифрового фільтра, вольт * 10
  int16_t  nofiltered_outI ;     // вихідний струм без цифрового фільтра,  ампер * 10
  int16_t  nofiltered_outE ;     // вихідний потеціал без цифрового фільтра, вольт * 100
  int16_t  nofiltered_outT ;     // температура без цифрового фільтра, град. цельсія * 10

  float    loadR ;          // опір навантаження, Ом

  int Volt=0
  int Cur=0
  int Pot=0
  int Res=0
  int WTime=0
  int Meter=0
  int ATemp=0
  int Temp=0
  int MEP=0
  int Mode=0
  int Error = 0 //помилка
  int Warning = 0 //попередження
*/


bool transferNewDateTime (bool calc) {
  uint32_t startMicros = micros();
  bool ret[2] = {0};
  log_i("Встановлення НОВИХ дати та часу NEXTION --> ESP32...");
  if (errors_flags.read(NO_WORK_NEXTION)) return false;

  if (transferDateTime()) {
    clear_error(ERROR_DATE_TIME, "");
    bitClear(preset.flags, 1);
    ret[0] = nextionSetVariable("gFlag", preset.flags);
    ret[1] = nextionSetVariable("gEvent", 1);
    if (ret[0] and ret[1]) {
      log_e("Успішне підтвердження застосування НОВИХ дати та часу ESP32 --> NEXTION...");
    } else {
      log_e("Помилка при передачі підтвердження застосування НОВИХ дати та часу ESP32 --> NEXTION...");
    }
  } else {
    log_e("Помилка при передачі НОВИХ дати та часу NEXTION --> ESP32...");
    set_error(ERROR_DATE_TIME, "Помилка встановлення дати!");
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer transferNewMeterSettings: %.1f", (micros() - startMicros) / 1000.0f);
  return (ret[0] and ret[1] and ret[2] and ret[3]);
}


bool transferMeterSettings(bool calc) {
  uint32_t startMicros = micros();
  bool ret[2] = {0};
  log_i("Встановлення показника лічильника та кількість імпульсів ESP32 --> NEXTION...");
  if (errors_flags.read(NO_WORK_NEXTION)) return false;

  ret[0] = nextionSetVariable("gMeter", (int32_t)(preset.meterkWh * 100.0f));
  ret[1] = nextionSetVariable("gQtyMet", preset.numberImpulses);
  // перевірка
  if (ret[0] and ret[1]) {
  } else {
    log_e("Помилка при передачі параметрів лічильника ESP32 ---> NEXTION");
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer transferMeterSettings: %.1f", (micros() - startMicros) / 1000.0f);
  return (ret[0] and ret[1]);
}

bool transferNewMeterSettings (bool calc) {
  uint32_t startMicros = micros();
  bool ret[4] = {0};
  log_i("Встановлення НОВИХ показника лічильника та кількість імпульсів NEXTION --> ESP32...");
  if (errors_flags.read(NO_WORK_NEXTION)) return false;

  int32_t tempMeter = 0;
  ret[0] = nextionGetVariable("Emeter.xMeter.val", tempMeter);
  ret[1] = nextionGetVariable("Emeter.nQty.val", preset.numberImpulses);
  if (ret[0] and ret[1]) {
    setting.putLong("numberImpulses", preset.numberImpulses);
    preset.meterkWh = (float)(tempMeter / 100.f);
    setting.putFloat("meterkWh", preset.meterkWh);
    bitClear(preset.flags, 2);
    ret[2] = nextionSetVariable("gFlag", preset.flags);
    ret[3] = nextionSetVariable("gEvent", 2);
    if (ret[2] and ret[3]) {
      setVariableMeter();
    } else {
      log_e("Помилка при передачі підтвердження застосування НОВИХ параметрів лічильника ESP32 --> NEXTION...");
    }
  } else {
    log_e("Помилка при передачі НОВИХ параметрів лічильника NEXTION --> ESP32...");
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer transferNewMeterSettings: %.1f", (micros() - startMicros) / 1000.0f);
  return (ret[0] and ret[1] and ret[2] and ret[3]);
}

/*
  int32_t  pidKp = 1000;          // Pid1.vnKp.val параметри ПІД регулятора
  int32_t  pidKi = 1000;          // Pid1.vnKi.val
  int32_t  pidKd = 300;           // Pid1.vnKd.val
  int32_t  pidTime = 200;         // Pid1.vnPidTime.val встановлює період у мілісекундах, при якому виконується розрахунок ПІД регулятора

  int32_t  pidPmode = 1;          // Pid2.vnPmode.val режим роботи пропорційної складової ПІД регулятора, pOnError (0), pOnMeas (1), pOnErrorMeas (2)
  int32_t  pidDmode = 1;          // Pid2.vnDmode.val режим роботи похідної складової ПІД регулятора , OnError (0), dOnMeas (1)
  int32_t  pidImode = 0;          // Pid2.vnImode.val режим роботи інтегральної складової ПІД регулятора, iAwCondition (0), iAwClamp (1), iAwOff (2)
  int32_t  pidMode = 1;           // Pid2.vnPidMode.val режим роботи ПІД регулятора, manual (0), automatic (1), timer (2)
*/

bool transferNewPIDSettings(bool calc) {
  uint32_t startMicros = micros();
  bool ret[10] = {0};
  log_i("Читаєм НОВІ параметри ПІД регулятора NEXTION --> ESP32...");
  if (errors_flags.read(NO_WORK_NEXTION)) return false;

  // прочитати НОВІ параметри ПІД регулятора
  ret[0] = nextionGetVariable("Pid1.vnKp.val", preset.pidKp);
  ret[1] = nextionGetVariable("Pid1.vnKi.val", preset.pidKi);
  ret[2] = nextionGetVariable("Pid1.vnKd.val", preset.pidKd);
  ret[3] = nextionGetVariable("Pid1.vnPidTime.val", preset.pidTime);

  ret[4] = nextionGetVariable("Pid2.vnPmode.val", preset.pidPmode);
  ret[5] = nextionGetVariable("Pid2.vnDmode.val", preset.pidDmode);
  ret[6] = nextionGetVariable("Pid2.vnImode.val", preset.pidImode);
  ret[7] = nextionGetVariable("Pid2.vnPidMode.val", preset.pidMode);

  // зберегти параметри та скинути флаг
  if (ret[0] and ret[1] and ret[2] and ret[3] and ret[4] and ret[5] and ret[6] and ret[7]) {
    setting.putLong("pidKp", preset.pidKp);
    setting.putLong("pidKi", preset.pidKi);
    setting.putLong("pidKd", preset.pidKd);
    setting.putLong("pidMode", preset.pidMode);
    setting.putLong("pidPmode", preset.pidPmode);
    setting.putLong("pidDmode", preset.pidDmode);
    setting.putLong("pidImode", preset.pidImode);
    setting.putLong("pidTime", preset.pidTime);
    bitClear(preset.flags, 3);
    ret[8] = nextionSetVariable("gFlag", preset.flags);
    ret[9] = nextionSetVariable("gEvent", 3);
    if (ret[8] and ret[9]) {
      myPIDSetup();
    } else {
      log_e("Помилка при передачі підтвердження застосування НОВИХ параметрів ПІД регулятора ESP32 --> NEXTION...");
    }
  } else {
    log_e("Помилка при передачі НОВИХ параметрів ПІД регулятора NEXTION --> ESP32...");
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer transferNewPIDSettings: %.1f", (micros() - startMicros) / 1000.0f);
  return  (ret[0] and ret[1] and ret[2] and ret[3] and ret[4] and ret[5] and ret[6] and ret[7] and ret[8] and ret[9]);
}

bool transferDefaultPIDSettings(bool calc) {
  uint32_t startMicros = micros();
  log_i("Застосовуємо ЗАВОДСЬКІ параметри ПІД регулятора...");
  bool ret[10] = {0};
  if (errors_flags.read(NO_WORK_NEXTION)) return false;

  preset.pidKp = preset.d_pidKp;
  preset.pidKi = preset.d_pidKi;
  preset.pidKd = preset.d_pidKd;
  preset.pidTime = preset.d_pidTime;
  preset.pidPmode = preset.d_pidPmode;
  preset.pidDmode = preset.d_pidDmode;
  preset.pidImode = preset.d_pidImode;
  preset.pidMode = preset.d_pidMode;

  setting.putLong("pidKp", preset.pidKp);
  setting.putLong("pidKi", preset.pidKi);
  setting.putLong("pidKd", preset.pidKd);
  setting.putLong("pidMode", preset.pidMode);
  setting.putLong("pidPmode", preset.pidPmode);
  setting.putLong("pidDmode", preset.pidDmode);
  setting.putLong("pidImode", preset.pidImode);
  setting.putLong("pidTime", preset.pidTime);

  myPIDSetup();

  // передати параметри ПІД регулятора
  ret[0] = nextionSetVariable("Pid1.xKp.val", preset.pidKp);
  ret[1] = nextionSetVariable("Pid1.xKi.val", preset.pidKi);
  ret[2] = nextionSetVariable("Pid1.xKd.val", preset.pidKd);
  ret[3] = nextionSetVariable("Pid1.nPidTime.val", preset.pidTime);

  ret[4] = nextionSetVariable("Pid2.nPmode.val", preset.pidPmode);
  ret[5] = nextionSetVariable("Pid2.nDmode.val", preset.pidDmode);
  ret[6] = nextionSetVariable("Pid2.nImode.val", preset.pidImode);
  ret[7] = nextionSetVariable("Pid2.nPidMode.val", preset.pidMode);


  // зберегти параметри та скинути флаг
  if (ret[0] and ret[1] and ret[2] and ret[3] and ret[4] and ret[5] and ret[6] and ret[7]) {
    bitClear(preset.flags, 4);
    ret[8] = nextionSetVariable("gFlag", preset.flags);
    ret[9] = nextionSetVariable("gEvent", 4);
    if (ret[8] and ret[9]) {
      //
    } else {
      log_e("Помилка при передачі підтвердження застосування НОВИХ ЗАВОДСЬКИХ параметрів ПІД регулятора ESP32 --> NEXTION...");
    }
  } else {
    log_e("Помилка при передачі НОВИХ ЗАВОДСЬКИХ параметрів ПІД регулятора NEXTION --> ESP32...");
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer transferNewPIDSettings: %.1f", (micros() - startMicros) / 1000.0f);
  return  (ret[0] and ret[1] and ret[2] and ret[3] and ret[4] and ret[5] and ret[6] and ret[7] and ret[8] and ret[9]);
}

bool transferPIDSettings(bool calc) {
  uint32_t startMicros = micros();
  log_i("Записуємо параметри ПІД регулятора ESP32 --> NEXTION...");
  bool ret[10] = {0};
  if (errors_flags.read(NO_WORK_NEXTION)) return false;

  // передати параметри ПІД регулятора
  ret[0] = nextionSetVariable("Pid1.xKp.val", preset.pidKp);
  ret[1] = nextionSetVariable("Pid1.xKi.val", preset.pidKi);
  ret[2] = nextionSetVariable("Pid1.xKd.val", preset.pidKd);
  ret[3] = nextionSetVariable("Pid1.nPidTime.val", preset.pidTime);

  ret[4] = nextionSetVariable("Pid2.nPmode.val", preset.pidPmode);
  ret[5] = nextionSetVariable("Pid2.nDmode.val", preset.pidDmode);
  ret[6] = nextionSetVariable("Pid2.nImode.val", preset.pidImode);
  ret[7] = nextionSetVariable("Pid2.nPidMode.val", preset.pidMode);

  // перевірка
  if (ret[0] and ret[1] and ret[2] and ret[3] and ret[4] and ret[5] and ret[6] and ret[7]) {
  } else {
    log_e("Помилка при передачі параметрів ПІД регулятора ESP32 ---> NEXTION");
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer transferPIDSettings: %.1f", (micros() - startMicros) / 1000.0f);
  return (ret[0] and ret[1] and ret[2] and ret[3] and ret[4] and ret[5] and ret[6] and ret[7]);
}

void readNextionPIDSettings() {
  int32_t ret[10] = {0};
  nextionGetVariable("Pid1.xKp.val", ret[0]);
  Serial.print("preset.pidKp    ="); Serial.print(preset.pidKp); Serial.print("\t"); Serial.print(ret[0]); Serial.println("");
  nextionGetVariable("Pid1.xKi.val", ret[1]);
  Serial.print("preset.pidKi    ="); Serial.print(preset.pidKi); Serial.print("\t"); Serial.print(ret[1]); Serial.println("");
  nextionGetVariable("Pid1.xKd.val", ret[2]);
  Serial.print("preset.pidKd    ="); Serial.print(preset.pidKd); Serial.print("\t"); Serial.print(ret[2]); Serial.println("");
  nextionGetVariable("Pid1.nPidTime.val", ret[3]);
  Serial.print("preset.pidTime  ="); Serial.print(preset.pidTime); Serial.print("\t"); Serial.print(ret[3]); Serial.println("");

  nextionGetVariable("Pid2.nPmode.val", ret[4]);
  Serial.print("preset.pidPmode ="); Serial.print(preset.pidPmode); Serial.print("\t"); Serial.print(ret[4]); Serial.println("");
  nextionGetVariable("Pid2.nDmode.val", ret[5]);
  Serial.print("preset.pidDmode ="); Serial.print( preset.pidDmode); Serial.print("\t"); Serial.print(ret[5]); Serial.println("");
  nextionGetVariable("Pid2.nImode.val", ret[6]);
  Serial.print("preset.pidImode ="); Serial.print(preset.pidImode); Serial.print("\t"); Serial.print(ret[6]); Serial.println("");
  nextionGetVariable("Pid2.nPidMode.val", ret[7]);
  Serial.print("preset.pidMode  ="); Serial.print(preset.pidMode); Serial.print("\t"); Serial.print(ret[7]); Serial.println("");
  nextionGetVariable("gFlag", ret[8]);
  Serial.print("preset.flags    ="); Serial.print(preset.flags); Serial.print("\t"); Serial.print(ret[8]); Serial.println("");
  nextionGetVariable("gEvent", ret[9]);
  Serial.print("gEvent          ="); Serial.print("?"); Serial.print("\t"); Serial.print(ret[9]); Serial.println("");
}

void transferDataNextion(bool calc) {
  uint32_t startMicros = micros();
  static uint8_t temp_display_brightness;
  bool ret[2] = {0};
  if (errors_flags.read(NO_WORK_NEXTION)) return;
  //Serial2.flush();
  //Serial2Clean();

  sendNextionCommand("code_c");
  uint32_t startMicros0 = micros();
  uint32_t delta = startMicros0 - startMicros;
  if (calc and delta > MIN_TIME) log_i("delta : %.1f", delta / 1000.0f);

  if (temp_display_brightness != preset.display_brightness) {
    char str[10] = {'\0'};
    char buf[10] = {'\0'};
    strcpy( str, "dim=" );
    sprintf(buf, "%d", preset.display_brightness);
    strcat( str, buf);
    ret[0] = sendNextionCommand(str);
    if (!ret[0]) nextionInit();
  }

  uint32_t startMicros1 = micros();
  delta = startMicros1 - startMicros0;
  if (calc and delta > MIN_TIME) log_i("delta1: %.1f", delta / 1000.0f);

  temp_display_brightness = preset.display_brightness;
  if (preset.display_brightness == MIN_DISPLAY_BRIGHTNESS) return;

  ret[1] = nextionGetVariable("gFlag", preset.flags);
  if (ret[1]) {
    if (bitRead(preset.flags, 1)) transferNewDateTime();
    if (bitRead(preset.flags, 2)) transferNewMeterSettings();
    if (bitRead(preset.flags, 3)) transferNewPIDSettings();
    if (bitRead(preset.flags, 4)) transferDefaultPIDSettings();
  } else {
    Serial.println("nextionInit()!");
    nextionInit();
  }

  uint32_t startMicros2 = micros();
  delta = startMicros2 - startMicros1;
  if (calc and delta > MIN_TIME) log_i("delta2: %.1f", delta / 1000.0f);

  nextionGetVariable("gPageid", preset.pageid);
  nextionSetVariable("gError", (int32_t)preset.error);
  nextionSetVariable("gWarning", (int32_t)preset.warning);

  uint32_t startMicros3 = micros();
  delta = startMicros3 - startMicros2;
  if (calc and delta > MIN_TIME) log_i("delta3: %.1f", delta / 1000.0f);

  nextionSetVariable("gMode", (int32_t)preset.mod);
  nextionSetVariable("gVolt", (int32_t)((preset.outU + 5) / 10));
  nextionSetVariable("gCur", (int32_t)((preset.outI + 5) / 10));
  nextionSetVariable("gPot", (int32_t)preset.outE);
  nextionSetVariable("gPow", (int32_t)(((preset.outI + 5) / 10) * ((preset.outU + 5) / 10) / 10));

  uint32_t startMicros4 = micros();
  delta = startMicros4 - startMicros3;
  if (calc and delta > MIN_TIME) log_i("delta4: %.1f", delta / 1000.0f);

  nextionSetVariable("gVoltU", (int32_t)((preset.setU + 5) / 10));
  nextionSetVariable("gCurU", (int32_t)((preset.setI + 5) / 10));
  nextionSetVariable("gPotU", (int32_t)preset.setE);

  uint32_t startMicros5 = micros();
  delta = startMicros5 - startMicros4;
  if (calc and delta > MIN_TIME) log_i("delta5: %.1f", delta / 1000.0f);

  nextionSetVariable("gATemp", (int32_t)preset.airT);
  nextionSetVariable("gTemp", (int32_t)preset.outT);
  nextionSetVariable("gWTime", (int32_t)((preset.hoursRunning + (float)(preset.minutesRunning / 60.0f)) * 10.0f));
  nextionSetVariable("gMeter", (int32_t)(preset.meterkWh * 100.0f));
  nextionSetVariable("gRes", (int32_t)(preset.loadR * 10.0f));

  uint32_t startMicros6 = micros();
  delta = startMicros6 - startMicros5;
  if (calc and delta > MIN_TIME) log_i("delta6: %.1f", delta / 1000.0f);

  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer transferDataNextion: %.1f", (micros() - startMicros) / 1000.0f);
}

// послати команду
bool sendNextionCommand(const char *command) {
  bool ret = false;
  nex.sendCommand (command);
  ret = nex.checkCommandComplete();
  if (!ret) {
    Serial.print("Error nex.sendCommand ");
    Serial.println(command);
  }
  return ret;
}

bool nextionGetVariable(const char *var, int32_t &value) {
  if (errors_flags.read(NO_WORK_NEXTION)) return false;
  bool ret = false;
  ret = nex.getVariable(var, value);
  return ret;
}

bool nextionSetVariable(const char *var, int32_t value) {
  if (errors_flags.read(NO_WORK_NEXTION)) return false;
  bool ret = false;
  ret = nex.setVariable(var, value);
  return ret;
}

/*
  void setup() {

  Serial2.begin(BAUD_RATE_NEXTION, SERIAL_8N1, RXD2, TXD2);
  //Serial2.setRxBufferSize(SERIAL_SIZE_RX);
  Serial2.setTimeout(500);

  // Сброс Nextion
  nex.restart();

  delay(2000);

  // Инициализация Nextion
  Serial2Clean();
  bool retNexInit = nex.init();

  if (retNexInit) {
    log_i("OK. Nextion работвет.");
    if (!transferDateTime()) log_e("Error Set Time in ESP32!");
  } else {
    log_e("Ошибка. Nextion не отвечает!");
    log_e("Дальнейшая работа невозможна!");
    // TODO:  Включить индикацию ошибки
  }

  )
*/
