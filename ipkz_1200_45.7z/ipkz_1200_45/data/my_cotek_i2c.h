#pragma once
#include "src/Eeprom24C01_02/Eeprom24C01_02.h"

#define COTEK_ADDR_MANUFACTURE 0x00            // 16
#define COTEK_ADDR_MODEL_NAME 0x10             // 16
#define COTEK_ADDR_REVISION 0x24               // 4
#define COTEK_ADDR_DATE_OF_MANUFACTURE 0x28    // 8 
#define COTEK_ADDR_SERIAL_NUMBER 0x30          // 16

#define COTEK_ADDR_NOMINAL_OUTPUT_VOLTAGE 0x50 // 2
#define COTEK_ADDR_NOMINAL_OUTPUT_CURRENT 0x52 // 2
#define COTEK_ADDR_MAX_VOLTAGE 0x54            // 2
#define COTEK_ADDR_MAX_CURRENT 0x56            // 2

#define COTEK_ADDR_OUTPUT_VOLTAGE 0x60         // 2
#define COTEK_ADDR_OUTPUT_CURRENT 0x62         // 2
#define COTEK_ADDR_TEMPERATURE 0x68            // 1

#define COTEK_ADDR_OUTPUT_STATUS_0 0x6C        // 1
#define COTEK_ADDR_OUTPUT_STATUS_1 0x6F        // 1
#define COTEK_ADDR_OUTPUT_SETTING_VOLTAGE 0x70 // 2
#define COTEK_ADDR_OUTPUT_SETTING_CURRENT 0x72 // 2
#define COTEK_ADDR_CONTROL 0x7C                // 1

String COTEK_SERIAL_NUMBER = "" ;              // серійний номер COTEK
byte COTEK_ADDRESS = 0x50;                    // I2C адреса COTEK

struct cotekRetString {
  int8_t error = 0;
  char value [20] = {'\0'};
};

struct cotekRetNomMaxUI {
  int16_t nomU = 0;
  int16_t nomI = 0;
  int16_t maxU = 0;
  int16_t maxI = 0;
};

Eeprom24C01_02 cotek (COTEK_ADDRESS);

//---------------------------------

cotekRetString readCotekString(byte address, byte count);
cotekRetNomMaxUI readCotekNomMaxUI();
void readCotekSN();
bool checkWorkCotek ();


// logging показати
void readCotekOutputUIT(bool calc = true);
void filterCotekOutputUIT(bool logging = false,  bool calc = true);
void readCotekSettingUI(bool logging = false,  bool calc = true);
void showUIP(bool calc = true);
void cotekError(uint8_t stus0 = preset.stus0, uint8_t stus1 = preset.stus1, uint8_t ctrl = preset.ctrl, bool calc = true);
void cotekSetUI(int16_t mod = preset.mod, int16_t setU = preset.setU, int16_t setI = preset.setI, int16_t setIE = preset.setIE, bool logging = true, bool calc = true);
void onCotek(bool calc = true);
//---------------------------------

// Якщо COTEK був відключений від I2C, то включити I2C
void onCotek(bool calc) {
  uint32_t startMicros  =  micros();
  // Якщо COTEK був відключений від I2C, то включити I2C
  if (bitRead(preset.stus1, 7) == 0)  {
    log_i("Якщо COTEK був відключений від I2C, то включити I2C");
    cotekSetUI ();
  }
  if (calc and (micros() - startMicros > MIN_TIME) ) log_i("Timer onCotek: %.1f", (micros() - startMicros) / 1000.0f);
}

// Вивести напругу, струм та потенціал на 7 сегментні індікатори

void showUIP(bool calc) {
  uint32_t startMicros  =  micros();
  char buf [10] = {'\0'};
  float temp = 0;

  seg7.Restart(preset.seg7_brightness);
  seg7.ClearRight();

  temp = (preset.outU + 1) / 100.0f;
  sprintf(buf, "%.1f", temp);
  seg7.print7SegRightText(buf, SEG7_U);

  temp = (preset.outI + 1) / 100.0f;
  sprintf(buf, "%.1f", temp);
  seg7.print7SegRightText(buf, SEG7_I);

  temp = preset.outE / 100.0f;
  if (errors_flags.read(OUT_RANGE_POTENCIAL) or errors_flags.read(ERROR_POTENCIAL)) {
    buf[0] = '\0';
  } else {
    sprintf(buf, "%.2f", temp);
  }
  seg7.print7SegRightText(buf, SEG7_E);

  seg7.ClearLeft();

  if ((preset.mod == SET_STAB_U) or (preset.mod == STAB_U) or (SEG7_VIEW_SETTING == 1) ) {
    temp = (preset.raw_setU + 1) / 100.0f;
    sprintf(buf, "%.1f", temp);
    seg7.print7SegLeftText(buf, SEG7_U, 1);
  }
  if ((preset.mod == SET_STAB_I) or (preset.mod == STAB_I) or (SEG7_VIEW_SETTING == 1) ) {
    temp = (preset.raw_setI + 1) / 100.0f;
    sprintf(buf, "%.1f", temp);
    seg7.print7SegLeftText(buf, SEG7_I, 1);
  }
  if ((preset.mod == SET_STAB_E) or (preset.mod == STAB_E) or (SEG7_VIEW_SETTING == 1) ) {
    temp = (preset.setE + 1) / 100.0f;
    sprintf(buf, "%.1f", temp);
    seg7.print7SegLeftText(buf, SEG7_E, 1);
  }
  seg7.Refresh();

  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer showUIP: %.1f", (micros() - startMicros) / 1000.0f);
}

//---------------------------------
// Прочитати вихідну напругу, струм та температуру
void readCotekOutputUIT(bool calc) {
  uint32_t startMicros  =  micros();
  byte outputBytes[4] = { 0 };
  if (errors_flags.read(NO_WORK_COTEK)) return; // якщо COTEK не працює вертаюмось

  cotek.readBytesCotek( COTEK_ADDR_OUTPUT_VOLTAGE , 4, outputBytes);
  //outputBytes[0] = cotek.readByteCotek( COTEK_ADDR_OUTPUT_VOLTAGE);
  //outputBytes[1] = cotek.readByteCotek( COTEK_ADDR_OUTPUT_VOLTAGE + 1);
  //outputBytes[2] = cotek.readByteCotek( COTEK_ADDR_OUTPUT_CURRENT);
  //outputBytes[3] = cotek.readByteCotek( COTEK_ADDR_OUTPUT_CURRENT + 1);
  preset.raw_outT = (int16_t) (cotek.readByteCotek( COTEK_ADDR_TEMPERATURE )); // температура без цифрового фільтра, град. цельсія
  preset.raw_outU = 256 * outputBytes[1] + outputBytes[0]; // вихідна напруга без цифрового фільтра, вольт * 100
  preset.raw_outI = 256 * outputBytes[3] + outputBytes[2]; // вихідний струм без цифрового фільтра,  ампер * 100

  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer readCotekOutputUIT: %.1f", (micros() - startMicros) / 1000.0f);
}

void filterCotekOutputUIT(bool logging, bool calc) {
  uint32_t startMicros  =  micros();

  preset.outU = (int16_t)(filterU.filtered((float)preset.raw_outU)); // відфільтрована вихідна напруга, вольт * 100
  preset.outI = (int16_t)(filterI.filtered((float)preset.raw_outI)); // відфільтрований вихідний струм, ампер * 100
  preset.outT = (int16_t)(filterT.filtered((float)preset.raw_outT)); // відфільтрована температура, град. цельсія * 100

  // preset.outU =  preset.raw_outU; // не відфільтрована вихідна напруга, вольт * 100
  // preset.outI =  preset.raw_outI; // не відфільтрований вихідний струм, ампер * 100
  // preset.outT = preset.raw_outT; // не відфільтрована температура, град. цельсія * 100

  if (preset.outI < 30) preset.outI = 0; // коррекція preset.outI

  if (logging) {
    log_i("preset.raw_outU       =%hd", preset.raw_outU);
    log_i("preset.outU           =%hd", preset.outU);
    log_i("preset.raw_outI       =%hd", preset.raw_outI);
    log_i("preset.outI           =%hd", preset.outI);
    //log_i("preset.raw_outT       =%hd", preset.raw_outT);
    //log_i("preset.outT           =%hd", preset.outT);
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer filterCotekOutputUIT: %.1f", (micros() - startMicros) / 1000.0f);
}

// Прочитати статус STATUS_0, STATUS_1, CONTROL, уставки напруги та струму
void readCotekSettingUI(bool logging, bool calc) {
  uint32_t startMicros  =  micros();
  byte outputBytes[4] = { 0 };

  if (errors_flags.read(NO_WORK_COTEK)) return; // якщо COTEK не працює вертаюмось

  cotek.readBytesCotek( COTEK_ADDR_OUTPUT_SETTING_VOLTAGE , 4, outputBytes);
  //outputBytes[0] = cotek.readByteCotek(COTEK_ADDR_OUTPUT_SETTING_VOLTAGE);
  //outputBytes[1] = cotek.readByteCotek(COTEK_ADDR_OUTPUT_SETTING_VOLTAGE + 1);
  //outputBytes[2] = cotek.readByteCotek(COTEK_ADDR_OUTPUT_SETTING_CURRENT);
  //outputBytes[3] = cotek.readByteCotek(COTEK_ADDR_OUTPUT_SETTING_CURRENT + 1);
  preset.raw_setU = 256 * outputBytes[1] + outputBytes[0];
  preset.raw_setI = 256 * outputBytes[3] + outputBytes[2];
  preset.stus0 = cotek.readByteCotek(COTEK_ADDR_OUTPUT_STATUS_0);
  preset.stus1 = cotek.readByteCotek(COTEK_ADDR_OUTPUT_STATUS_1);
  preset.ctrl = cotek.readByteCotek(COTEK_ADDR_CONTROL);

  if (logging) {
    log_i("preset.raw_setU=%hd", preset.raw_setU);
    log_i("preset.raw_setI=%hd", preset.raw_setI);
    log_i("preset.stus0   =" BYTE_TO_BINARY_PATTERN, BYTE_TO_BINARY(preset.stus0));
    log_i("preset.stus1   =" BYTE_TO_BINARY_PATTERN, BYTE_TO_BINARY(preset.stus1));
    log_i("preset.ctrl    =" BYTE_TO_BINARY_PATTERN, BYTE_TO_BINARY(preset.ctrl));
  }
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer readCotekSettingUI: %.1f", (micros() - startMicros) / 1000.0f);
}



/*
  Address   Byte  Function            Type
  ------------------------------------------------
  0x00-0x0F 16  Manufacture           Read
  0x10-0x1F 16  Model name            Read
  0x20-0x23 4   (Not  used)
  0x24-0x27 4   Revision              Read
  0x28-0x2F 8   Date of manufacture   Read
  0x30-0x3F 16  Serial Number         Read
  0x40-0x4F 16  Country of  MFG.      Read
  0x50-0x51 2   Rated Output Voltage  Read
  0x52-0x53 2   Rated Output Current  Read
  0x54-0x55 2   Max. Output Voltage   Read
  0x56-0x57 2   Max. Output Current   Read
  0x58-0x5F 8   (Not used)
  0x60-0x61 2   Output voltage        Read
  0x62-0x63 2   Output current        Read
  0x64-0x67 4   (Not used)
  0x68      1   Internal Temperature  Read
  0x69-0x6B 3   (Not used)
  0x6C      1   Status:0              Read
  0x6D-0x6E 2   (Not used)
  0x6F      1   Status:1              Read
  0x70-0x71 2   O/P Voltage setting   R/W
  0x72-0x73 2   O/P Current setting   R/W
  0x74-0x79 6   (Not used)
  0x7A      1   **  Reserve **
  0x7B      1   **  Reserve **
  0x7C      1   Control               R/W
  0x7D-0x7F 3   **  Reserve **
*/

//---------------------------------

// встановити напругу та струм, якщо режим STAB_U, SET_STAB_U, STAB_I, SET_STAB_I, STAB_E або SET_STAB_E
// відключити, якщо режим POWER_OFF
void cotekSetUI (int16_t mod, int16_t setU , int16_t setI, int16_t setIE, bool logging, bool calc ) {

  if (errors_flags.read(NO_WORK_COTEK)) return; // якщо COTEK не працює вертаюмось

  uint32_t startMicros  =  micros();
  if (mod == STAB_U or mod == SET_STAB_U) setI = MAX_I;
  if (mod == STAB_I or mod == SET_STAB_I) setU = MAX_U;
  if (mod == STAB_E  or mod == SET_STAB_E) setU = MAX_U;

  byte ctrl = 0xff;


  if (mod == SET_STAB_E or mod == STAB_E) setI = setIE;

  
  if (logging) {
    log_i("Встановлення напруги та струму!");
    log_i("Уставка setI=%hd", setI);
    log_i("Уставка setU=%hd", setU);
  }
  
  //setU = constrain(setU, MIN_U, MAX_U);
  //setI = constrain(setI, MIN_I, MAX_I);
  //setIE = constrain(setIE, MIN_I, MAX_I);

  cotek.writeByte (COTEK_ADDR_OUTPUT_SETTING_CURRENT, lowByte ((word)setI));
  cotek.writeByte (COTEK_ADDR_OUTPUT_SETTING_CURRENT + 1, highByte ((word)setI));
  cotek.writeByte (COTEK_ADDR_OUTPUT_SETTING_VOLTAGE, lowByte ((word)setU));
  cotek.writeByte (COTEK_ADDR_OUTPUT_SETTING_VOLTAGE + 1, highByte ((word)setU));
  ctrl  = cotek.readByteCotek (COTEK_ADDR_CONTROL);
  if (mod == POWER_OFF) {
    bitClear(ctrl, 0); // PWR OFF
  } else {
    bitSet(ctrl, 0); // PWR ON
  }
  bitSet(ctrl, 7); // Control by Software
  bitSet(ctrl, 2); // Update
  cotek.writeByte (COTEK_ADDR_CONTROL , ctrl);
  ctrl = 0xff;
  while (bitRead(ctrl, 2) != 0) {
    ctrl  = cotek.readByteCotek (COTEK_ADDR_CONTROL);
  }
  if ((bitRead(ctrl, 2) == 0) && (bitRead(ctrl, 3) == 0)) { // Update Complete
    clear_error (COMMAND_ERROR_COTEK, " ");
    clear_error (UPDATE_NOT_COMPLETE_COTEK, " ");
  }
  if ((bitRead(ctrl, 2) == 0) && (bitRead(ctrl, 3) == 1)) { // Update Complete, Command Error
    set_error (COMMAND_ERROR_COTEK, "Update Complete, Command Error");
  }
  if (bitRead(ctrl, 2) != 0) { // Update Not Complete
    set_error (UPDATE_NOT_COMPLETE_COTEK, "Update Not Complete");
  }

  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer cotekSetUI: %.1f", (micros() - startMicros) / 1000.0f);
}

//---------------------------------

// Прочитати строку з address довжиною count
cotekRetString readCotekString(byte address, byte count) {

  cotekRetString ret;
  byte outputBytes[count] = { 0 };

  if (errors_flags.read(NO_WORK_COTEK)) return ret; // якщо COTEK не працює вертаємось

  cotek.readBytesCotek( address , count, outputBytes);
  for (byte i = 0; i < count ; i++)
  {
    ret.value[i] = (char)outputBytes[i];
  }
  ret.value[count] = '\0';
  return ret;
}

//---------------------------------

// Прочитати номінальну та максимальну напругу та струм
cotekRetNomMaxUI readCotekNomMaxUI() {

  cotekRetNomMaxUI ret;
  byte outputBytes[8] = { 0 };

  if (errors_flags.read(NO_WORK_COTEK)) return ret; // якщо COTEK не працює вертаюмось

  cotek.readBytesCotek( COTEK_ADDR_NOMINAL_OUTPUT_VOLTAGE , 8, outputBytes);
  ret.nomU = 256 * outputBytes[1] + outputBytes[0];
  ret.nomI = 256 * outputBytes[3] + outputBytes[2];
  ret.maxU = 256 * outputBytes[5] + outputBytes[4];
  ret.maxI = 256 * outputBytes[7] + outputBytes[6];
  return ret;
}

//---------------------------------

void readCotekSN() {

  if (errors_flags.read(NO_WORK_COTEK)) return; // якщо COTEK не працює вертаємось

  cotekRetString ret;
  ret = readCotekString(COTEK_ADDR_SERIAL_NUMBER, 16);
  COTEK_SERIAL_NUMBER = (const char*)ret.value;
  log_i ("COTEK SERIAL NUMBER: %s", ret.value);
}

//---------------------------------

// Перевірка чи є Cotek
bool checkWorkCotek () {
  Wire.beginTransmission (COTEK_ADDRESS);          // Begin I2C transmission address COTEK_ADDRESS
  if (Wire.endTransmission () == 0)                // Receive 0 = success (ACK response)
  {
    clear_error(NO_WORK_COTEK, "Cotek працює!");
    return true;
  } else {
    set_error(NO_WORK_COTEK, "Cotek не знайдено!");
    return false;
  }
}

//---------------------------------

/*
  Status_0 Register
     Bit-0 -> OVP Shutdown
     Bit-1 -> OLP Shutdown
     Bit-2 -> OTP Shutdown
     Bit-3 -> FAN Failure
     Bit-4 -> AUX or SMPS Fail
     Bit-5 -> HI-TEMP Alarm
     Bit-6 -> AC Power De-rating
     Bit-7 -> AC Input Failure

  Status_1 Register
     Bit-0 -> 0 = SMPS works normal, вкл.
              1 = Inhibit by VCI, ACI or INHI signal
     Bit-1 -> 1 = CMD > 0.5V
              0 = CMD < 0.3V
     Bit-2 -> (Not used.)
     Bit-3 -> (Not used.)
     Bit-4 -> 1 = Power ON
              0 = Power OFF
     Bit-5 -> (Not used.)
     Bit-6 -> (Not used.)
     Bit-7 -> 1 = Control by I2C or RS-232 / 485, Rempte mode
              0 = Control by VCI, ACI, EN, Local mode

  Control Register (0x7C)
     Bit-0 -> Power control  0:PWR-OFF, 1:PWR-ON
     Bit-1 -> (Not used)
     Bit-2 -> Command update 0:Complete, 1:Required
     Bit-3 -> Command error  0:Valid, 1:Error
     Bit-4 -> (Not used)
     Bit-5 -> (Not used)
     Bit-6 -> ** Reserve **
     Bit-7 -> Remote control 0:Control by VCI,ACI, ENB
                             1:Control by Software (I2C or RS232/485)
*/

//---------------------------------

void cotekError(uint8_t stus0, uint8_t stus1, uint8_t ctrl, bool calc) {

  if (errors_flags.read(NO_WORK_COTEK)) return; // якщо COTEK не працює вертаємось
  uint32_t startMicros  =  micros();
  if ((stus0 == 0) && (stus1 == 0) && (ctrl == 0)) { // Немає звязку з COTEK
    set_error (NO_WORK_COTEK, "Немає зв'язку з силовим блоком або силовий блок відключений від мережі 220В");
    return;
  }
  if (bitRead(stus0, 0) == 1) {  // OVP Shutdown Over Voltage Protection
    set_error (OVP_COTEK, "Спрацював захист від перенапруги");
    return;
  }
  if (bitRead(stus0, 1) == 1) {  // OLP Shutdown Over Load Protection
    set_error (OLP_COTEK, "Спрацював захист від перевантаження");
    return;
  }
  if (bitRead(stus0, 2) == 1) {  // OTP Shutdown Over Tepmerature Protection
    set_error (OTP_COTEK, "Спрацював захист від перегріву, внутрішня температура понад 85°C");
    return;
  }
  if (bitRead(stus0, 3) == 1) {  // Fan Failure Shutdown
    set_error (NO_FAN_COTEK, "Спрацював захист, вихід з ладу вентилятора ");
    return;
  }
  if (bitRead(stus0, 4) == 1) {  // AUX or SMPS Fail
    set_error (NO_AUX_COTEK, "Помилка силового блока живлення");
    return;
  }
  if (bitRead(stus0, 7) == 1) {  // AC Input Failure
    set_error (AC_FAILURE_COTEK, "Немає мережі 220В");
    return;
  }
  if (bitRead(stus1, 0) == 0) {  // SMPS works normal in Local mode
    set_error (LOCAL_MODE_COTEK, "SMPS works normal in Local mode");
    return;
  }
  if (bitRead(stus1, 4) == 0) {  // Power OFF
    preset.mod = setting.getShort("mod");
    if (preset.mod != POWER_OFF) {
      set_error (POWER_OFF_COTEK, "Режим очікування");
      return;
    }
  }
  if (bitRead(stus1, 7) == 0) {  // Control by VCI, ACI, EN
    set_error (CONTROL_LOCAL_COTEK, "Control by VCI, ACI, EN, локальний режим");
    return;
  }
  if (bitRead(stus0, 5) == 1) {  // High Temperature Alarm
    set_warning (TEMP_ALARM_COTEK, "Сигналізація про високу, понад 75°C, внутрішню температуру");
    return;
  }
  if (bitRead(stus0, 6) == 1) {  // AC Power De-rating
    set_warning (AC_LOW_COTEK, "Зниження вхідної напруги в мережі 220В");
    return;
  }
  clear_error (NO_WORK_COTEK, " ");
  clear_error (OVP_COTEK, " ");
  clear_error (OLP_COTEK, " ");
  clear_error (OTP_COTEK, " ");
  clear_error (NO_FAN_COTEK, " ");
  clear_error (NO_AUX_COTEK, " ");
  clear_error (AC_FAILURE_COTEK, " ");
  clear_error (LOCAL_MODE_COTEK, " ");
  clear_error (POWER_OFF_COTEK, " ");
  clear_error (CONTROL_LOCAL_COTEK, " ");
  clear_warning (TEMP_ALARM_COTEK, " ");
  clear_warning (AC_LOW_COTEK, " ");

  if (calc and (micros() - startMicros > MIN_TIME))  log_i("Timer cotekError: %.1f", (micros() - startMicros) / 1000.0f);
}



//---------------------------------
