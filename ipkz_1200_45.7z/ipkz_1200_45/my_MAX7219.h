#pragma once
#include "src/HCMAX7219/HCMAX7219.h"
#include <SPI.h> // DIN -> MOSI 23, LOAD -> CS 5, CLK -> SCLK 18

// імя та номер піну семисегментного індикатора
#define SEG7_PIN 5        // номер піну вибіру чіпу CS семисегментного індикатора LOAD (CS)
#define NUMBEROFDRIVERS 3 // кількість 7-сігментних індикатори

// імя та номер 7 сегментного індиквтору
#define SEG7_U         1    // індикатор напруги (верхній)
#define SEG7_I         2    // індикатор струму (середній)
#define SEG7_E         3    // індикатор потенціалу (нижній)

 HCMAX7219 seg7(SEG7_PIN, MAX_SEG7_BRIGHTNESS);

//---------------------------------

void Seg7Intensity(byte);
void Seg7Test(bool Mode = TESTMODEON);
void Seg7TestDelay(bool Mode = TESTMODEON);
void Seg7BuzzerInit();

//---------------------------------

void Seg7Test(bool Mode) // TESTMODEON или TESTMODEOFF
{
  for (byte DriverIndex = 0; DriverIndex < NUMBEROFDRIVERS; DriverIndex++)
  {
    seg7.TestMode(Mode, DriverIndex);
    seg7.Refresh();
  }
}

//---------------------------------

void Seg7Intensity(byte Intensity) // TESTMODEON или TESTMODEOFF
{
  for (byte DriverIndex = 0; DriverIndex < NUMBEROFDRIVERS; DriverIndex++)
  {
    seg7.Intensity(Intensity, DriverIndex);
    seg7.Clear();
    seg7.Refresh();
  }
}

//---------------------------------

void Seg7TestDelay(bool Mode) {
  Seg7Test(Mode);
  vTaskDelay(PERIOD_SHOW_INDICATOR / portTICK_PERIOD_MS);
}

//---------------------------------

void Seg7BuzzerInit() {
  buzzerBeep(200);
  ledOnAll();
  Seg7TestDelay(TESTMODEON);
  ledOffAll();
  Seg7TestDelay(TESTMODEOFF);
  buzzerBeep(200);
  ledOnAll();
  Seg7TestDelay(TESTMODEON);
  ledOffAll();
  Seg7TestDelay(TESTMODEOFF);
  buzzerBeep(200);
  ledOnAll();
  Seg7TestDelay(TESTMODEON);
  ledOffAll();
  Seg7TestDelay(TESTMODEOFF);
  Seg7Intensity(preset.seg7_brightness);
}

//---------------------------------
