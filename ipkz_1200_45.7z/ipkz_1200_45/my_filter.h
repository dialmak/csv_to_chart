#include "GyverFilters.h"
// параметры: разброс измерения, разброс оценки, скорость изменения значений
// разброс измерения: шум измерений
// разброс оценки: подстраивается сам, можно поставить таким же как разброс измерения
// скорость изменения значений: 0.001-1, варьировать самому
GKalman filterU(100, 100, 0.1);
GKalman filterI(100, 100, 0.1);
GKalman filterE(30, 30, 0.1);
GKalman filterT(3, 3, 0.5);
GKalman filterTA(3, 3, 0.5);

// параметры: период дискретизации (измерений), process variation, noise variation
//GABfilter filterU(0.5, 500, 5);
// GABfilter filterIII(0.5, 260, 5);
//GABfilter filterT(0.5, 100, 5);
//GABfilter filterE(0.5, 1000, 5);
//GABfilter filterTA(0.5, 100, 5);

/*
void setup() {
  Serial.begin(9600);
}
void loop() {
  delay(80);
  int value = analogRead(0);
  value += random(2) * random(-1, 2) * random(10, 70);
  Serial.print("$");
  Serial.print(value);
  Serial.print(" ");
  value = testFilter.filtered((int)value);
  Serial.print(value);
  Serial.println(";");
}
*/

/*
float _err_measure = 0.4;  // примерный шум измерений
float _q = 0.2;   // скорость изменения значений 0.001-1, варьировать самому
float simpleKalman(float newVal) {
  float _kalman_gain, _current_estimate;
  static float _err_estimate = _err_measure;
  static float _last_estimate;
  _kalman_gain = (float)_err_estimate / (_err_estimate + _err_measure);
  _current_estimate = _last_estimate + (float)_kalman_gain * (newVal - _last_estimate);
  _err_estimate =  (1.0 - _kalman_gain) * _err_estimate + fabs(_last_estimate - _current_estimate) * _q;
  _last_estimate = _current_estimate;
  return _current_estimate;
}
*/
