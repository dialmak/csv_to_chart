#pragma once

// #include <sTune.h>
#include "src/QuickPID/QuickPID.h"

Ticker timerSetupPotencial;
Ticker timerSetup;
Ticker timerSetupPID;
void endSetup(bool beep = true);


//Define Variables we'll be connecting to
float pidSetPoint, pidInput, pidOutput;

//Specify PID links
QuickPID myPID(&pidInput, &pidOutput, &pidSetPoint);

void runningPIDSetup();
void myPIDSetup();
void myPIDLoop(bool logging = false);

/*
  sTune tuner = sTune(&pidInput, &pidOutput, tuner.ZN_PID , tuner.directIP, tuner.printDEBUG);
  // sTune(float *pidInput, float *pidOutput, TuningRule tuningRule, Action action, SerialMode serialMode);

  uint32_t testTimeSec = 5; // 200 раз по 300 мс = 60 сек
  const uint16_t samples = 200; // 200 точек
  uint32_t settleTimeSec = 1;
  const float inputSpan = 999;
  float sstop = MAX_I;
  const float outputSpan = 2500;
  float outputStart = 100;
  float outputStep = 1000;



  void tunerSetup();
  void myPIDSetup();
  void myPIDLoop(bool logging = true);


  void tunerSetup()
  {
  pidSetPoint = 200;
  tuner.Configure(inputSpan, outputSpan, outputStart, outputStep, testTimeSec, settleTimeSec, samples);
  //tuner.SetEmergencyStop(sstop);
  }
*/

void runningPIDSetup() {
    myPIDSetup();
}

void myPIDSetup()
{
  //  apply PID gains
  //  enum class Control : uint8_t {manual, automatic, timer};        // controller mode
  //  enum class Action : uint8_t {direct, reverse};                  // controller action
  //  enum class pMode : uint8_t {pOnError, pOnMeas, pOnErrorMeas};   // proportional mode
  //  enum class dMode : uint8_t {dOnError, dOnMeas};                 // derivative mode
  //  enum class iAwMode : uint8_t {iAwCondition, iAwClamp, iAwOff};  // integral anti-windup mode
  float temp_Kp = (float)(preset.pidKp / 1000.0f);
  float temp_Ki = (float)(preset.pidKi / 1000.0f);
  float temp_Kd = (float)(preset.pidKd / 1000.0f);
  if (preset.pidPmode == 0) myPID.SetProportionalMode(myPID.pMode::pOnError);
  if (preset.pidPmode == 1) myPID.SetProportionalMode(myPID.pMode::pOnMeas);
  if (preset.pidPmode == 2) myPID.SetProportionalMode(myPID.pMode::pOnErrorMeas);
  if (preset.pidImode == 0) myPID.SetAntiWindupMode(myPID.iAwMode::iAwCondition);
  if (preset.pidImode == 1) myPID.SetAntiWindupMode(myPID.iAwMode::iAwClamp);
  if (preset.pidImode == 2) myPID.SetAntiWindupMode(myPID.iAwMode::iAwOff);
  if (preset.pidDmode == 0) myPID.SetDerivativeMode(myPID.dMode::dOnError);
  if (preset.pidDmode == 1) myPID.SetDerivativeMode(myPID.dMode::dOnMeas);
  uint32_t temp_Time = (uint32_t)(preset.pidTime * 1000);
  myPID.SetSampleTimeUs(temp_Time);

  myPID.SetTunings(temp_Kp, temp_Ki, temp_Kd);
  myPID.SetOutputLimits((float)MIN_I, (float)MAX_I);
  myPID.SetControllerDirection(myPID.Action::direct);
  if (preset.pidMode == 0) myPID.SetMode(myPID.Control::manual);
  if (preset.pidMode == 1) myPID.SetMode(myPID.Control::automatic);
  if (preset.pidMode == 2) myPID.SetMode(myPID.Control::timer);

  /*
    uint8_t GetMode();        // manual (0), automatic (1) or timer (2)
    uint8_t GetDirection();   // direct (0), reverse (1)
    uint8_t GetPmode();       // pOnError (0), pOnMeas (1), pOnErrorMeas (2)
    uint8_t GetDmode();       // dOnError (0), dOnMeas (1)
    uint8_t GetAwMode();      // iAwCondition (0, iAwClamp (1), iAwOff (2)
    void SetSampleTimeUs(uint32_t NewSampleTimeUs); // Set PID compute sample time, default = 100000 µs
    void SetProportionalMode(pMode pMode);          // Set pTerm based on error (default), measurement, or both
    void SetDerivativeMode(dMode dMode);            // Set the dTerm, based error or measurement (default).
    void SetAntiWindupMode(iAwMode iAwMode);        // Set iTerm anti-windup to iAwCondition, iAwClamp or iAwOff

    enum class Control : uint8_t {manual, automatic, timer};        // controller mode
    enum class Action : uint8_t {direct, reverse};                  // controller action
    enum class pMode : uint8_t {pOnError, pOnMeas, pOnErrorMeas};   // proportional mode
    enum class dMode : uint8_t {dOnError, dOnMeas};                 // derivative mode
    enum class iAwMode : uint8_t {iAwCondition, iAwClamp, iAwOff};  // integral anti-windup mode
  */
}


void myPIDLoop(bool logging) {
  static uint32_t n;
  static uint16_t previosOutput;

  pidInput = (float)(-preset.outE);
  pidSetPoint = (float)(-preset.setE);

  if (myPID.Compute()) {
    preset.setIE = (int16_t) (pidOutput + 0.5);
    float tempPterm = myPID.GetPterm();
    float tempIterm = myPID.GetIterm();
    int16_t tempChangeOutput = previosOutput - preset.setIE;
    int16_t tempChangeInput = pidInput - pidSetPoint;

    if (logging) {
      Serial.println("---------------------------------------------------------");
      Serial.print("tempChangeOutput="); Serial.println(tempChangeOutput);
      Serial.print("tempChangeInput ="); Serial.println(tempChangeInput);
      Serial.print("Kp()            ="); Serial.println(myPID.GetKp());
      Serial.print("Ki()            ="); Serial.println(myPID.GetKi());
      Serial.print("Kd()            ="); Serial.println(myPID.GetKd());
      Serial.print("tempPterm       ="); Serial.println(tempPterm);
      Serial.print("tempIterm       ="); Serial.println(tempIterm);
    }

    if (!timerSetupPotencial.active() and tempPterm == 0 and tempIterm == 0 and preset.mod == SET_STAB_E) {
      log_i("Потенціал стабілізовано!");
      setting.putShort("setIE", preset.setIE);
      preset.setUI = preset.outU;
      setting.putShort("setUI", preset.setUI);
      if (logging) {
        Serial.print("preset.setIE    ="); Serial.println(preset.setIE);
      }
      if (logging) {
        Serial.print("preset.setUI    ="); Serial.println(preset.setUI);
      }
      endSetup(true);
    }

    // if ((abs(tempChangeOutput) >= 20) or (abs(tempChangeInput) >= 2) or (abs(tempPterm) >= 0.3) or (abs(tempIterm) >= 0.3)) {

    if ((abs(tempPterm) >= 0.3) or (abs(tempIterm) >= 0.3)) {
      n++;
      if (logging) {
        Serial.print("n               =");
        Serial.println(n);
      }
        cotekSetUI(preset.mod, preset.setU, preset.setI, preset.setIE, true);
    }
    previosOutput = preset.setIE;
  }

}
