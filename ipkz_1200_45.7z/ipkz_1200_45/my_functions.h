#pragma once

const int wdtTimeout = 5000;  // таймаут watchdog
hw_timer_t *wdtTimer = NULL;


//---------------------------------


void checkWorkNextionCotek(unsigned long timeout_ms = 10000,  bool calc = false);
String getDeviceID();
uint32_t getChipID();
void initWatchDogTimer();
void watchDogRefresh();
void ARDUINO_ISR_ATTR resetModule();


void checkWorkNextionCotek(unsigned long timeout_ms, bool calc) {
  static volatile uint32_t timerStart = millis();
  if (millis() - timerStart > timeout_ms) {
    // скидання таймера
    timerStart = millis();
    uint32_t startMicros  =  micros();
    if (errors_flags.read(NO_WORK_NEXTION)) nextionInit();
    if (errors_flags.read(NO_WORK_COTEK)) checkWorkCotek();
    if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer checkWorkNextionCotek: %.1f", (micros() - startMicros) / 1000.0f);
  }
}


//get device id
String getDeviceID() {
  uint64_t chipid = ESP.getEfuseMac(); // The chip ID is essentially its MAC address(length: 6 bytes).
  uint16_t chip = (uint16_t)(chipid >> 32);
  char devID[40];
  snprintf(devID, 40, "%04X%08X", chip, (uint32_t)chipid);
  return devID;
}

// get Chip ID
uint32_t getChipID() {
  uint32_t chipId = 0;
  for (int i = 0; i < 17; i = i + 8) {
    chipId |= ((ESP.getEfuseMac() >> (40 - i)) & 0xff) << i;
  }

  Serial.printf("ESP32 Chip model = %s Rev %d\n", ESP.getChipModel(), ESP.getChipRevision());
  Serial.printf("This chip has %d cores\n", ESP.getChipCores());
  Serial.print("Chip ID: "); Serial.println(chipId);

  return chipId;
}

void initWatchDogTimer() {
  wdtTimer = timerBegin(0, 80, true);                  //timer 0, div 80
  timerAttachInterrupt(wdtTimer, &resetModule, false);  //attach callback
  timerAlarmWrite(wdtTimer, wdtTimeout * 1000, false); //set time in us
  timerAlarmEnable(wdtTimer);   //enable interrupt
}


// Примусове скидання
void ARDUINO_ISR_ATTR resetModule() {
  log_i("Скидання...");
  esp_restart();
}

void watchDogRefresh()
{
  timerWrite(wdtTimer, 0); //reset timer (feed watchdog)
}


//---------------------------------
