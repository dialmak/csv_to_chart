#pragma once
#include <WiFi.h>
#include <WiFiAP.h>

bool execOnce = true;

const char * ssid = "AC-IPKZ";
const char * passphrase = NULL;
const char * hostname = "0007 IPKZ-1200-50";

IPAddress local_IP(10,1,1,1);
IPAddress gateway(10,1,1,1);
IPAddress subnet(255,255,255,0);

void initAP (bool param = execOnce);
const char * getAPHostName ();
void setAPHostName (const char * hostname);
String getAPssid ();
String  getAPmacAddress ();
uint8_t getAPNumClients ();
void closeAP ();
void WiFiOff ();
void WiFiEvent (bool param = execOnce);
void OnWiFiEvent(WiFiEvent_t event);


void initAP (bool param) {
  if (param) {
    execOnce = false; 

    WiFi.mode(WIFI_AP);

    Serial.print("Setting soft-AP configuration ... ");
    Serial.println(WiFi.softAPConfig(local_IP, gateway, subnet) ? "Ready" : "Failed!");
    
    delay (100);
    
    // WiFi.softAP(ssid, passphrase, channel, ssdi_hidden, max_connection)
    Serial.print("Setting soft-AP ... ");
    Serial.println(WiFi.softAP(ssid, passphrase, 6, false, 50) ? "Ready" : "Failed!");
    
    Serial.print("Soft-AP IP address = ");
    Serial.println(WiFi.softAPIP());
  }
}


const char * getAPHostName () {
  Serial.print("Get soft-AP host name... ");
  const char * hostname = WiFi.softAPgetHostname();
  Serial.println(hostname);
  return hostname;
}

void setAPHostName (const char * hostname) {
  Serial.print("Set soft-AP host name... ");
  Serial.println(WiFi.softAPsetHostname(hostname) ? "Ready" : "Failed!");
}

String getAPssid () {
  Serial.print("Get soft-AP SSID ... ");
  Serial.println(WiFi.softAPSSID());
  return WiFi.softAPSSID();
}

String  getAPmacAddress () {
  Serial.print("Soft-AP MAC Address ... ");
  Serial.println(WiFi.softAPmacAddress());
  return WiFi.softAPmacAddress();
}

uint8_t getAPNumClients () {
  return WiFi.softAPgetStationNum();
}

void closeAP () {  
  Serial.print("Close soft-AP ... ");
  Serial.println(WiFi.softAPdisconnect(true) ? "Ready" : "Failed!");
  WiFi.mode(WIFI_OFF);
}

void WiFiOff () {
  Serial.print("WIFI OFF ...");
  Serial.println(WiFi.mode(WIFI_OFF) ? "Ready" : "Failed!");
  
}

void OnWiFiEvent(WiFiEvent_t event)
{
  switch (event) {
 
    case SYSTEM_EVENT_STA_CONNECTED:
      Serial.println("ESP32 Connected to WiFi Network");
      break;
    case SYSTEM_EVENT_AP_START:
      Serial.println("ESP32 soft AP started");
      break;
    case WIFI_EVENT_AP_STOP:
      Serial.println("ESP32 soft AP stopped");
      break;  
    case SYSTEM_EVENT_AP_STACONNECTED:
      Serial.println("Station connected to ESP32 soft AP");
      break;
    case SYSTEM_EVENT_AP_STADISCONNECTED:
      Serial.println("Station disconnected from ESP32 soft AP");
      break;
    case WIFI_EVENT_MAX:
      Serial.println("Invalid WiFi event ID");
      break;      
      
    default: break;
  }
}

void WiFiEvent (bool param) { // Реєстрація подій для WiFi. Виконати один раз ДО вкл. soft-AP.
  if (param) {
    execOnce = false; 
    WiFi.onEvent(OnWiFiEvent);
  }
}
