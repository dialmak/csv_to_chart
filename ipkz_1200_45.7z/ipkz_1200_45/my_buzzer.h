#pragma once
#include <Ticker.h>

#define BUZZER_PIN   12

Ticker tickerGoBeep;
Ticker tickerEndBeep;

//---------------------------------

void buzzerInit();
void buzzerSet(int state);
void buzzerBeep(uint32_t timer_in_ms);

//---------------------------------

void buzzerInit() {
  pinMode (BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
}

void buzzerSet(int state) {
  digitalWrite(BUZZER_PIN, state);
}

void buzzerBeep (uint32_t timer_in_ms) {
  buzzerSet(1);
  tickerEndBeep.once_ms(timer_in_ms, buzzerSet, 0);
}
