#pragma once
Ticker tickerRunningTime;

void runningTime();

void runningTime() {
  if ((preset.outU > 0) and (preset.outI > 0) ) {
    preset.minutesRunning++;
    if (preset.minutesRunning == 60) {
      preset.minutesRunning = 0;
      preset.hoursRunning++;
      setting.putULong("hoursRunning", preset.hoursRunning);
    }
    if (preset.minutesRunning == 0 or preset.minutesRunning == 10 or preset.minutesRunning == 20 or preset.minutesRunning == 30 or preset.minutesRunning == 40 or preset.minutesRunning == 50) {
      setting.putULong("minutesRunning", preset.minutesRunning);
    }
    log_i ("Час напрацювання перетворювача: %02lu годин %02lu хвилин", preset.hoursRunning, preset.minutesRunning);
  }
}
