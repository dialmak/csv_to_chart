// NTC Thermistor
// the formula for temp in kelvin is
//                 1
// T = ----------------------------
//     1/To + (1/beta) * ln(Rt/Ro)
//
// https://en.wikipedia.org/wiki/Thermistor

#define THERMISTOR_PIN 32          // імя та номер піну термістора
double readVoltage(uint8_t pin = THERMISTOR_PIN);
double readTemp (uint8_t pin = THERMISTOR_PIN);
void timerReadTemperature(unsigned long timeout_us);


//---------------------------------------------------------
double readVoltage(uint8_t pin) {
  analogReadResolution(12);
  double reading = analogRead(pin);     // Reference voltage is 3v3 so maximum reading is 3v3 = 4095 in range 0 to 4095
  if (reading < 1 || reading > 4095) return 0;
  // return -0.000000000009824 * pow(reading,3) + 0.000000016557283 * pow(reading,2) + 0.000854596860691 * reading + 0.065440348345433;
  return -0.000000000000016 * pow(reading, 4) + 0.000000000118171 * pow(reading, 3) - 0.000000301211691 * pow(reading, 2) + 0.001109019271794 * reading + 0.034143524634089;
}                                       // Added an improved polynomial, use either, comment out as required


double readTemp(uint8_t pin) {
  double Vs = 3.3;                       // supply voltage
  double R1 = 9980.0;                    // voltage divider resistor value
  double Beta = 3280.0;                  // Beta value
  double To = 298.15;                    // Temperature in Kelvin for 25 degree Celsius
  double Ro = 10000.0;                   // Resistance of Thermistor at 25 degree Celsius
  double Vout, Rt = 0;
  double T, Tc, Tf = 0;
  Vout = readVoltage(pin);
  Rt = R1 * Vout / (Vs - Vout);
  T = 1 / (1 / To + log(Rt / Ro) / Beta); // Temperature in Kelvin
  Tc = T - 273.15;                        // Temperature in Celsius
  float tmp = filterTA.filtered(Tc);       // фільтруєм температуру
  if (tmp > 0) {
    preset.airT = tmp + 0.5;
  } else if (tmp < 0) {
    preset.airT = tmp - 0.5;
  } else {
    preset.airT = 0;
  }
  return Tc;
}

void timerReadTemperature(unsigned long timeout_us) {
  static volatile uint32_t timerStart = millis();
  if (millis() - timerStart > timeout_us) {
    // скидання таймера
    timerStart = millis();
    readTemp();
    log_d("Напруга ADC = %.2f V", readVoltage());
    log_d("Температура = %.2f °C", readTemp());
    log_d("Температура = %i °C", preset.airT);

  }
}
