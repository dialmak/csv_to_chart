#pragma once

#include <Ticker.h>
#include <SPI.h>                                           // DIN -> MOSI 23, CLK -> SCLK 18

// імя та номер піну регистру зсуву HC595 для світлодіодів
#define CS_HC595_PIN    15                                 // імя та номер піну вибіру чіпу CS регистру зсуву HC595 для світлодіодів
#define CS_HC595_SET()  digitalWrite(CS_HC595_PIN, LOW)    // вибір CS регистру зсуву HC595 перед записом
#define CS_HC595_RESET()  digitalWrite(CS_HC595_PIN, HIGH) // скидання CS регистру зсуву HC595 після запису даних

// імя та номер світлодіоду

#define MODE_U          0x0001    // світлодіод зелений "СТАБ. НАПРУГИ" U 
#define MODE_I          0x0002    // світлодіод жовтий "СТАБ. СТРУМУ" I
#define MODE_E          0x0004    // світлодіод синій "СТАБ. ПОТЕНЦІАЛУ" E
#define MODE_OFF        0x0008    // світлодіод червоний "ВИМКНУТИ ВИХІД" OFF

// Світлодіод "ЖИВЛЕННЯ СИЛОВОГО БЛОКУ" зелений підключений до COTEK.
// Світлодіод "СТАН ВИХОДУ" зелений підключений до COTEK.

// світлодіод "НОРМА\ПОПЕРЕДЖЕННЯ\ПОМИЛКА"

#define STATUS_GREEN    0x0100     // зелений    НОРМА
#define STATUS_YELLOW   0x0300     // жовтий
#define STATUS_RED      0x0200     // червоний   ПОМИЛКА
#define STATUS_BLUE     0x0800     // синій      ПОПЕРЕДЖЕННЯ
#define STATUS_MAGENTA  0x0A00     // пурпурний
#define STATUS_CYAN     0x0900     // блакитний
#define STATUS_WHITE    0x0B00     // білий

// світлодіод "АВТОМАТИЧНИЙ\РУЧНИЙ РЕЖИМ"

#define MODE_GREEN      0x0400     // зелений 
#define MODE_RED        0x1000     // червоний
/*
  #define MODE_YELLOW     0x1400     // жовтий
  #define MODE_BLUE       0x0800     // синій
  #define MODE_MAGENTA    0x1800     // пурпурний
  #define MODE_CYAN       0x0С00     // блакитний
  #define MODE_WHITE      0x1С00     // білий
*/

// світлодіод "ОПІР НАВАНТАЖЕННЯ НОРМА\БІЛЬШЕ 10 ОМ\БІЛЬШЕ 20 ОМ"

#define LOAD_GREEN      0x2000     // зелений   НОРМА
#define LOAD_YELLOW     0xA000     // жовтий
#define LOAD_RED        0x8000     // червоний  БІЛЬШЕ 20 ОМ
#define LOAD_BLUE       0x4000     // синій     БІЛЬШЕ 10 ОМ
#define LOAD_MAGENTA    0xC000     // пурпурний
#define LOAD_CYAN       0x6000     // блакитний
#define LOAD_WHITE      0xE000     // білий

// тривалість вкл. та відкл. світлодіодів
#define LED_DELAY_OFF   650        // тривалість відкл. світлодіодів
#define LED_DELAY_ON    350        // тривалість вкл. світлодіодів

// ініціалізація CH595 та погасити світлодіоди
void ledInit();
void ledOnAll();
void ledOffAll();
void setLed(bool logging = false);


//---------------------------------

// Ініціалізація світлодіодів
void ledInit() {
  pinMode(CS_HC595_PIN, OUTPUT);
  CS_HC595_RESET();
  ledOffAll();
}

//---------------------------------

// Засвітити всі світлодіоди
void ledOnAll() {
  CS_HC595_SET();
  uint16_t value = 0xFFFF;
  SPI.transfer(highByte(value));
  SPI.transfer(lowByte(value));
  CS_HC595_RESET();
}

//---------------------------------

// Погасити всі світлодіоди
void ledOffAll() {
  CS_HC595_SET();
  uint16_t value = 0x0000;
  SPI.transfer(highByte(value));
  SPI.transfer(lowByte(value));
  CS_HC595_RESET();
}

//---------------------------------


void setLed(bool logging) {
  static volatile uint16_t led_status = 0;

  uint16_t value = 0;
  if (preset.mod == STAB_U) {
    value |= MODE_U | MODE_GREEN;
  }
  if (preset.mod == STAB_I) {
    value |= MODE_I | MODE_GREEN;
  }
  if (preset.mod == STAB_E) {
    value |= MODE_E | MODE_GREEN;
  }
  if (preset.mod == POWER_OFF) {
    value |= MODE_OFF | MODE_RED;
  }

  if (preset.mod == SET_STAB_U) value |= MODE_RED;
  if (preset.mod == SET_STAB_I) value |= MODE_RED;
  if (preset.mod == SET_STAB_E) value |= MODE_RED;

  if ((preset.mod == SET_STAB_U) and (!bitRead(led_status, 0))) value |= MODE_U;
  if ((preset.mod == SET_STAB_I) and (!bitRead(led_status, 1))) value |= MODE_I;
  if ((preset.mod == SET_STAB_E) and (!bitRead(led_status, 2))) value |= MODE_E;

  uint16_t tmp_res = 0;
  preset.loadR = 0;
  if (preset.mod != POWER_OFF) {
    if (preset.outI != 0 and preset.outU >= OFFSET_U) {
      preset.loadR = (float)preset.outU / preset.outI;
      tmp_res = round((float)preset.outU / preset.outI);
      clear_error(BREAK_LOAD_CIRCUIT, "Навантаження є!");
      if ( tmp_res > 0 and tmp_res <= 10) {
        value |= LOAD_GREEN;
      } else if ( tmp_res > 10 and tmp_res <= 20) {
        value |= LOAD_BLUE;
      } else if ( tmp_res > 20) {
        value |= LOAD_RED;
      }
    } else if (preset.outI == 0 and preset.outU >= OFFSET_U) {
      value |= LOAD_RED;
      set_error(BREAK_LOAD_CIRCUIT, "Обрив ланцюга наванаження!");
    } else {
      // value |= LOAD_RED;
    }
  }

  if (findErrorsFlags()) {
    value |= STATUS_RED;
  } else if (checkWarningsFlags()) {
    value |= STATUS_BLUE;
  } else {
    value |= STATUS_GREEN;
  }

  if (digitalRead(DOOR_SENSOR_PIN) == LOW) value = 0;
  led_status = value;
  CS_HC595_SET();
  SPI.transfer(highByte(value));
  SPI.transfer(lowByte(value));
  CS_HC595_RESET();

  if (logging) {
    log_i ("preset.outU      = %ld V", preset.outU);
    log_i ("preset.outI      = %ld A", preset.outI);
    log_i ("preset.loadR     = %.2f", preset.loadR);
    log_i ("tmp_res          = %ld Om", tmp_res);
    log_i ("findErrorsFlags  = %d", findErrorsFlags());
    log_i ("checkWarningsFlags = %d", checkWarningsFlags ());
  }
}


/*
  void setup() {
  SPI.begin();
  SPI.setBitOrder(MSBFIRST);

  // ініціалізація CH595 та погасити світлодіоди
  ledInit();

  // тест світлодіодів
  delay(500);
  ledOnAll();
  delay(500);
  ledOffAll();
  delay(500);
  ledOnAll();
  delay(500);
  ledOffAll();
  delay(500);
  ledOnAll();
  }
*/
