#pragma once

Ticker tickerDoorSensor;
void checkDoorSensor();
void changeDoor();

void checkDoorSensor() {
  if (digitalRead(DOOR_SENSOR_PIN) == LOW) {
    preset.seg7_brightness = MIN_SEG7_BRIGHTNESS;
    preset.display_brightness = MIN_DISPLAY_BRIGHTNESS;
  } else {
    preset.seg7_brightness = MAX_SEG7_BRIGHTNESS;
    preset.display_brightness = MAX_DISPLAY_BRIGHTNESS;
  }
}

void changeDoor() {
  tickerDoorSensor.once_ms(200, checkDoorSensor);
  buzzerBeep(50);
}
