#pragma once

// імя та номер піну для входу лічильника електроенергії
#define POWER_METER_PIN 27 // вхід лічильника електроенергії

volatile uint8_t pulseCount = 0;           // загальна кількість імпульсів
volatile uint8_t meterCount = 0;           // лічильник, збільшується коли pulseCount == (preset.numberImpulses/1000 * 10 * 2), в данному випадку кожні 128 pulseCount
volatile uint16_t tmp_iwh = 128;           // тимчасова змінна

void setVariableMeter(bool calc = false);
void IRAM_ATTR onPulse();
void getPulseCount();

//------------------------------------------------------------
void setVariableMeter(bool calc) {
  uint32_t startMicros  =  micros();
  preset.meterkWh =  setting.getFloat("meterkWh");
  preset.numberImpulses = setting.getLong("numberImpulses");
  float iwh = preset.numberImpulses / 1000.0f;
  tmp_iwh = (uint16_t)(iwh * 10 * 2);
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer setVariableMeter: %.1f", (micros() - startMicros) / 1000.0f);
}

//------------------------------------------------------------
// переривання
void IRAM_ATTR onPulse() {
  portENTER_CRITICAL_ISR(&mux);
  pulseCount++;
  if (pulseCount >= tmp_iwh) {
    meterCount++;
    pulseCount = 0;
  }
  portEXIT_CRITICAL_ISR(&mux);
}

//------------------------------------------------------------
//
void getPulseCount() {
  if (meterCount >= 1) {
    portENTER_CRITICAL(&mux);
    meterCount = 0;
    portEXIT_CRITICAL(&mux);
    preset.meterkWh =  0.01f + preset.meterkWh;
    log_i("Кількість імпульсів на 1 кВт*ч : %ld", preset.numberImpulses);
    log_i("Тимчасова змінна               : %ld", tmp_iwh );
    log_i("Показник лічильника            : %.2f kW*h", preset.meterkWh );
    setting.putFloat("meterkWh", preset.meterkWh);
  }
}


/*
  void setup()
  {
  Serial.begin(115200);

  pinMode(POWER_METER_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(POWER_METER_PIN), onPulse, FALLING);
  }

  void loop()
  {
  getPulseCount();
  }
*/
