#pragma once
#include "src/ButtonFever/BfButton.h"

// імя та номер піну кнопок
#define btnU_PIN       35   // кнопка переходу у режим стабілізації напруги
#define btnI_PIN       34   // кнопка переходу у режим стабілізації струму
#define btnE_PIN       39   // кнопка переходу у режим стабілізації потенціалу
#define btnOFF_PIN     36   // кнопка переходу у режим очікування
#define btnENCODER_PIN 26   // кнопка енкодера


BfButton btnU(BfButton::STANDALONE_DIGITAL, btnU_PIN, false, LOW);
BfButton btnI(BfButton::STANDALONE_DIGITAL, btnI_PIN, false, LOW);
BfButton btnE(BfButton::STANDALONE_DIGITAL, btnE_PIN, false, LOW);
BfButton btnOFF(BfButton::STANDALONE_DIGITAL, btnOFF_PIN, false, LOW);
BfButton btnENCODER(BfButton::STANDALONE_DIGITAL, btnENCODER_PIN, false, LOW);

//---------------------------------

void getPreset(bool logging = false);
void goSetupMode();
void goNormalMode();
void pressHandler (BfButton *btn, BfButton::press_pattern_t pattern);
void pressHandlerEncoder (BfButton *btn, BfButton::press_pattern_t pattern);
void setBtnPressHandler();
void btnRead(bool calc = false);
void timerPotencialOff();


//---------------------------------


void btnRead (bool calc) {
  uint32_t startMicros  =  micros();
  checkWorkNextionCotek();
  readTemp();
  btnU.read();
  btnI.read();
  btnE.read();
  btnOFF.read();
  btnENCODER.read();
  if (calc and (micros() - startMicros > MIN_TIME)) log_i("Timer btnRead: %.1f", (micros() - startMicros) / 1000.0f);
}

// прочитати preset.setU, preset.setI, preset.setE, preset.setIE та preset.mod
// якщо logging = true  вивести в лог log_i

void getPreset(bool logging) {
  // Прочитати уставку напруги setU
  preset.setU = setting.getShort("setU");
  if (preset.setU < MIN_U) {
    log_e("Некорректний preset.setU: %hd", preset.setU);
    preset.setU = MIN_U;
    setting.putShort("setU", preset.setU);
  } else if (preset.setU > MAX_U) {
    log_e("Некорректний preset.setU: %hd", preset.setU);
    preset.setU = MAX_U;
    setting.putShort("setU", preset.setU);
  }

  // Прочитати уставку струму setI
  preset.setI = setting.getShort("setI");
  if (preset.setI < MIN_I) {
    log_e("Некорректний preset.setI: %hd", preset.setI);
    preset.setI = MIN_I;
    setting.putShort("setI", preset.setI);
  } else if (preset.setI > MAX_I) {
    log_e("Некорректний preset.setI: %hd", preset.setI);
    preset.setI = MAX_I;
    setting.putShort("setI", preset.setI);
  }

  // Прочитати уставку потенціалу setE
  preset.setE = setting.getShort("setE");
  if (preset.setE < MIN_E) {
    log_e("Некорректний preset.setE: %hd", preset.setE);
    preset.setE = MIN_E;
    setting.putShort("setE", preset.setE);
  } else if (preset.setE > MAX_E) {
    log_e("Некорректний preset.setE: %hd", preset.setE);
    preset.setE = MAX_E;
    setting.putShort("setE", preset.setE);
  }

  // Прочитати уставку струму для потенціалу  setIE
  preset.setIE = setting.getShort("setIE");
  if (preset.setIE < MIN_I) {
    log_e("Некорректний preset.setIE: %hd", preset.setIE);
    preset.setIE = MIN_I ;
    setting.putShort("setIE", preset.setI);
  } else if (preset.setIE > MAX_I) {
    log_e("Некорректний preset.setIE: %hd", preset.setIE);
    preset.setIE = MAX_I;
    setting.putShort("setIE", preset.setIE);
  }

  // Прочитати уставку струму для потенціалу setUI
  preset.setUI = setting.getShort("setUI");

  // Отримати встановлений режим mod
  preset.mod = setting.getShort("mod");
  if ((preset.mod < POWER_OFF) || (preset.mod > SET_STAB_E)) {
    log_e("Некорректний preset.mod: %hd", preset.mod);
    preset.mod = STAB_I;
    setting.putShort("mod", preset.mod);
  }

  // Вивести в лог
  if (logging) {
    log_i("preset.setU: %hd", preset.setU);
    log_i("preset.setI: %hd", preset.setI);
    log_i("preset.setE: %hd", preset.setE);
    log_i("preset.setIE: %hd", preset.setIE);
    log_i("preset.setUI: %hd", preset.setUI);
    log_i("preset.mod: %hd", preset.mod);
  }
}

//---------------------------------

void timerPotencialOff() {
  Serial.println("Таймер настройки потенціала виключений.");
}


void endSetup(bool beep) {
  timerSetup.detach();
  timerSetupPotencial.detach();

  if  ((preset.mod == SET_STAB_I) and ((preset.setI - preset.outI) < 200)) {
    preset.setUI = preset.outU;
    setting.putShort("setUI", preset.setUI);
  }

  if  (preset.mod == SET_STAB_U)  preset.mod = STAB_U;
  if  (preset.mod == SET_STAB_I)  preset.mod = STAB_I;
  if  (preset.mod == SET_STAB_E)  preset.mod = STAB_E;

  setting.putShort("mod", preset.mod);
  // скинути btn_pr_pressed
  preset.btn_pr_pressed = 0 ;
  log_i("Закінчився таймаут налаштування.");
  if (beep) buzzerBeep(400);
}

//---------------------------------

// перехід у режим налаштування
void goSetupMode() {
  // якщо нажата та сама кнопка 2 рази підряд та preset.mod в режимі SET_STAB_U, SET_STAB_I або SET_STAB_E, то тоді переходимо в режими STAB_U, STAB_I, STAB_E або POWER_OFF
  if ((preset.btn_pr_pressed == preset.btn_pressed) &&  ((preset.mod == SET_STAB_U) || (preset.mod == SET_STAB_I) || (preset.mod == SET_STAB_E))) {
    if (preset.btn_pressed == btnU_PIN) {
      preset.mod = STAB_U;
    } else if (preset.btn_pressed == btnI_PIN) {
      preset.mod = STAB_I;
    } else if (preset.btn_pressed == btnE_PIN) {
      preset.mod = STAB_E;
    } else if (preset.btn_pressed == btnOFF_PIN) {
      preset.mod = POWER_OFF;
    }
    endSetup(false);

  } else {

    if (preset.btn_pressed == btnU_PIN) {
      preset.mod = SET_STAB_U;
      timerSetup.once_ms(TIMER_SETUP, endSetup, true);
    } else if (preset.btn_pressed == btnI_PIN) {
      preset.mod = SET_STAB_I;
      timerSetup.once_ms(TIMER_SETUP, endSetup, true);
    } else if (preset.btn_pressed == btnE_PIN) {
      preset.mod = SET_STAB_E;
      timerSetup.detach();
      timerSetupPotencial.once_ms(TIMER_SETUP , timerPotencialOff);
    } else if (preset.btn_pressed == btnOFF_PIN) {
      timerSetup.detach();
      preset.mod = POWER_OFF;
    }

    // встановити btn_pr_pressed
    if (settings_flags.read(NO_ELECTROD) and (preset.mod == SET_STAB_E)) {
      preset.btn_pr_pressed = 34;
    } else {
      preset.btn_pr_pressed = preset.btn_pressed;
    }

  }

  // записати новий режим preset.mod
  setting.putShort("mod", preset.mod);

  if (preset.mod == SET_STAB_U) log_i("Перехід в режим настройки стабілізації напруги!");
  if (preset.mod == SET_STAB_I) log_i("Перехід в режим настройки стабілізації струму!");
  if (preset.mod == SET_STAB_E) log_i("Перехід в режим настройки стабілізації потенціалу!");
  if (preset.mod == STAB_U) log_i("Перехід в режим стабілізації напруги, кінець настройки напруги!");
  if (preset.mod == STAB_I) log_i("Перехід в режим стабілізації струму, кінець настройки струму!");
  if (preset.mod == STAB_E) log_i("Перехід в режим стабілізації потенціалу, кінець настройки потенціалу!");
  if (preset.mod == POWER_OFF) log_i("Перехід в режим очікування!");

  // прочитати налаштування preset.setU, preset.setI, preset.mod
  getPreset();

  // Встановити режим та напругу й струм
  cotekSetUI ();
}

//---------------------------------

void goNormalMode() {
  // якщо нажата та сама кнопка 2 рази підряд та preset.mod в режимі SET_STAB_U, SET_STAB_I або SET_STAB_E, то тоді переходимо в режими STAB_U, STAB_I, STAB_E або POWER_OFF
  if  ((preset.btn_pr_pressed == preset.btn_pressed) && ((preset.mod == SET_STAB_U) || (preset.mod == SET_STAB_I))) {
    endSetup(false);
  }
}

//---------------------------------

void pressHandler (BfButton *btn, BfButton::press_pattern_t pattern) {
  preset.btn_pressed = btn->getID();
  switch (pattern) {
    case BfButton::SINGLE_PRESS:
      buzzerBeep(10);
      log_d("Single press   : %hhu", preset.btn_pressed);
      log_d("Previos pressed: %hhu", preset.btn_pr_pressed);
      goNormalMode();
      break;

    case BfButton::DOUBLE_PRESS:
      buzzerBeep(100);
      log_d("Double pressed : %hhu", preset.btn_pressed);
      log_d("Previos pressed: %hhu", preset.btn_pr_pressed);
      break;

    case BfButton::LONG_PRESS:
      buzzerBeep(400);
      log_d("Long pressed   : %hhu", preset.btn_pressed);
      log_d("Previos pressed: %hhu", preset.btn_pr_pressed);
      goSetupMode();
      break;

    default:
      break;
  }
}

//---------------------------------

void pressHandlerEncoder (BfButton *btn, BfButton::press_pattern_t pattern) {
  preset.btn_pressed = btn->getID();
  switch (pattern) {
    case BfButton::SINGLE_PRESS:
      if  ((preset.mod != SET_STAB_U) and (preset.mod != SET_STAB_I) and (preset.mod != SET_STAB_E) ) {
        buzzerBeep(10);
        sendNextionCommand(bOK);
      }
      log_d("Single press   : %hhu", preset.btn_pressed);
      log_d("Previos pressed: %hhu", preset.btn_pr_pressed);
      break;

    case BfButton::DOUBLE_PRESS:
      if  ((preset.mod != SET_STAB_U) and (preset.mod != SET_STAB_I) and (preset.mod != SET_STAB_E) ) {
        buzzerBeep(100);
      }
      log_d("Double pressed : %hhu", preset.btn_pressed);
      log_d("Previos pressed: %hhu", preset.btn_pr_pressed);
      break;

    case BfButton::LONG_PRESS:
      log_d("Long pressed   : %hhu", preset.btn_pressed);
      log_d("Previos pressed: %hhu", preset.btn_pr_pressed);
      // скидання процесора
      if ((preset.mod == POWER_OFF) and (digitalRead(DOOR_SENSOR_PIN) == HIGH) and (digitalRead(btnOFF_PIN) == LOW)) {
        buzzerBeep(1500);
        delay(1500);
        ESP.restart();
      }
      if  ((preset.mod != SET_STAB_U) and (preset.mod != SET_STAB_I) and (preset.mod != SET_STAB_E) ) {
        buzzerBeep(400);
        sendNextionCommand(bHold);
      }
      break;

    default:
      break;
  }

}

//---------------------------------

void setBtnPressHandler() {
  btnENCODER.onPress(pressHandlerEncoder)
  .onDoublePress(pressHandlerEncoder, 600)
  .onPressFor(pressHandlerEncoder, 3000); // custom timeout for 3 second
  btnU.onPress(pressHandler)
  .onDoublePress(pressHandler, 600)
  .onPressFor(pressHandler, 3000); // custom timeout for 3 second
  btnI.onPress(pressHandler)
  .onDoublePress(pressHandler, 600)
  .onPressFor(pressHandler, 3000); // custom timeout for 3 second
  btnE.onPress(pressHandler)
  .onDoublePress(pressHandler, 600)
  .onPressFor(pressHandler, 3000); // custom timeout for 3 second
  btnOFF.onPress(pressHandler)
  .onDoublePress(pressHandler, 600)
  .onPressFor(pressHandler, 3000); // custom timeout for 3 second
}

/*

  void setup() {

  btnENCODER.onPress(pressHandlerEncoder)
  .onPressFor(pressHandlerEncoder, 2000); // custom timeout for 2 second
  btnU.onPress(pressHandler)
  .onPressFor(pressHandler, 2000); // custom timeout for 2 second
  btnI.onPress(pressHandler)
  .onPressFor(pressHandler, 2000); // custom timeout for 2 second
  btnE.onPress(pressHandler)
  .onPressFor(pressHandler, 2000); // custom timeout for 2 second
  btnOFF.onPress(pressHandler)
  .onPressFor(pressHandler, 2000); // custom timeout for 2 second

  }

  void loop() {
  btnU.read();
  btnI.read();
  btnE.read();
  btnOFF.read();
  btnENCODER.read();
  }
*/
