#pragma once
#include "src/BitPack/BitPack.h"

// кількість прапорів помилок
#define ERRORS_FLAGS_QTY 25

// кількість прапорів пропереджень
#define WARNINGS_FLAGS_QTY 25

// кількість прапорів налаштуваннь
#define SETTINGS_FLAGS_QTY 25

BitPack <ERRORS_FLAGS_QTY> errors_flags;
BitPack <WARNINGS_FLAGS_QTY> warnings_flags;
BitPack <SETTINGS_FLAGS_QTY> settings_flags;

bool findErrorsFlags ();
// byte checkErrorsFlags ();
byte checkWarningsFlags ();
void set_error (byte flag, const char * text);
void clear_error (byte flag, const char * text);
void set_warning (byte flag, const char * text);
void clear_warning (byte flag, const char * text);
void set_setting (byte flag, const char * text);
void clear_setting (byte flag, const char * text);

//void set_error (byte flag, char text[]);
//void clear_error (byte flag, char text[]);

// прапори попереджень

// Сигналізація про високу, понад 75°C, внутрішню температуру
#define TEMP_ALARM_COTEK     1

// Зниження вхідної напруги в мережі 220В
#define AC_LOW_COTEK         2

// Немаю зв'язку з електролічильником
#define NO_ELECTRIC_METER    3

// Перевірка
#define CHECK_WARNING        25

// --------------------------------------
// прапори налаштуваннь

// Наявність електрода порівняння, якщо електрода немає, то встановлений режим стаб. потенціалу змінюється на режим стаб. струму
#define NO_ELECTROD          1



// --------------------------------------
// прапори помилок

// Немає мережі 220В.
#define AC_FAILURE_COTEK     1

// Обрив ланцюга навантаження.
#define BREAK_LOAD_CIRCUIT   2

// Немає зв'язку з силовим блоком або силовий блок відключений від мережі 220В.
#define NO_WORK_COTEK        3

// Немаю живлення дісплея або немає зв'язку з дісплеєм або дісплей не працює.
#define NO_WORK_NEXTION      4

// Невірна дата, встановіть коректну дату та час.
#define INCORRECT_DATE       5

// Помилка обміну даними між дісплеєм і процесором під час передачі дати та часу.
#define ERROR_DATE_TIME      6

// Не працює схема вимірювання потенціалу.
#define NO_WORK_INA219       7

// Помилка вимірювання захисного потенціалу.
#define ERROR_POTENCIAL      8

// Захисний потенціал не в діапазоні -10В ... +5В.
#define OUT_RANGE_POTENCIAL  9

// Спрацював захист від перенапруги.
#define OVP_COTEK            10

// Спрацював захист від перевантаження.
#define OLP_COTEK            11

// Спрацював захист від перегріву, внутрішня температура понад 90°C.
#define OTP_COTEK            12

// Спрацював захист, вихід з ладу вентилятора.
#define NO_FAN_COTEK         13

// Помилка основного силового або допоміжного блока живлення.
#define NO_AUX_COTEK         14

// Силовий блок в незапланованому локальному режимі.
// SMPS works normal in Local mode
#define LOCAL_MODE_COTEK     15

// Силовий блок в незапланованому режимі очікування.
#define POWER_OFF_COTEK      16

// Control by VCI, ACI, EN, локальний режим
// Зв'язок з силовим блоком втрачений. Силовий блок в локальному режимі.
#define CONTROL_LOCAL_COTEK  17

// Update Complete, Command Error
// Помилка обміну даними між силовим блоком і процесором. Некоректна команда для силового блоку.
#define COMMAND_ERROR_COTEK  18

// Update Not Complete
// Помилка обміну даними між силовим блоком і процесором. Силовий блок не прийняв команду.
#define UPDATE_NOT_COMPLETE_COTEK  19

// CHECK_ERROR
#define CHECK_ERROR          25
// --------------------------------------

bool findErrorsFlags ()
{
  preset.error = 0;
  for (byte n = ERRORS_FLAGS_QTY ; n >= 1; n--) {
    if (errors_flags.read(n) == 1) {
      preset.error = n;
    }
  }
  return preset.error;
}

/*
  byte checkErrorsFlags ()
  {
  byte counter = 0 ;
  for (byte n = 1 ; n <= ERRORS_FLAGS_QTY; n++) {
    counter += errors_flags.read(n);
  }
  return counter;
  }
*/
// --------------------------------------

byte checkWarningsFlags ()
{
  byte counter = 0 ;
  for (byte n = 1 ; n <= WARNINGS_FLAGS_QTY; n++) {
    counter += warnings_flags.read(n);
  }
  return counter;
}

// --------------------------------------

void set_error (byte flag, const char * text)
{
  if (!errors_flags.read(flag)) {
    Serial.println(text);
  }
  errors_flags.set(flag);
}

// --------------------------------------

void clear_error (byte flag, const char * text)
{
  if (errors_flags.read(flag)) {
    Serial.println(text);
  }
  errors_flags.clear(flag);
}

// --------------------------------------

void set_warning (byte flag, const char * text)
{
  if (!warnings_flags.read(flag)) {
    Serial.println(text);
  }
  warnings_flags.set(flag);
}

// --------------------------------------

void clear_warning (byte flag, const char * text)
{
  if (warnings_flags.read(flag)) {
    Serial.println(text);
  }
  warnings_flags.clear(flag);
}

// --------------------------------------

void set_setting (byte flag, const char * text)
{
  if (!settings_flags.read(flag)) {
    Serial.println(text);
  }
  settings_flags.set(flag);
}

// --------------------------------------

void clear_setting (byte flag, const char * text)
{
  if (settings_flags.read(flag)) {
    Serial.println(text);
  }
  settings_flags.clear(flag);
}
// --------------------------------------

// опустити всі прапори помилок та попереджень
//errors_flags.clearAll();
//warnings_flags.clearAll();
//settings_flags.clearAll();

/*
  void set(uint8_t num);                  // установить
  void clear(uint8_t num);                // сбросить
  void toggle(uint8_t num);               // переключить
  void write(uint8_t num, bool state);    // записать
  bool read(uint8_t num);                 // прочитать
  void setAll();                          // установить все
  void clearAll();                        // сбросить все


  flags.clearAll(); // опустить все
  flags.set(1);     // поднять флаг
  flags.set(3);
  flags.write(3, 1);
  Serial.println(flags.read(0));  // прочитать флаг
  Serial.println(flags.read(1));
  Serial.println(flags.read(2));
  flags[3] = 0;        // можно писать через []
  Serial.println(flags[3]); // можно читать через []

*/
